# EduBharat — Content Templates
*For content creators, video producers, and question writers*
*Status: [FINAL] | Last updated: May 2026*

---

## Template 1: Video Script Format

```
VIDEO SCRIPT TEMPLATE
=====================
Platform: EduBharat
Class: [6 / 7 / 8]
Subject: [Maths / Science / SST / English / Hindi]
Chapter: [Chapter number and name]
Topic: [Specific topic within chapter]
Duration Target: 5-7 minutes
Language Version: [English / Hindi]
NCERT Reference: Chapter [X], Pages [X-Y]

LEARNING OUTCOMES (what student can DO after this video):
1. [Outcome 1]
2. [Outcome 2]
3. [Outcome 3]

---

SCENE 1 — HOOK (0:00 - 0:30)
On-screen: [Describe animation/visual]
Narration: [Exact words to be spoken]
Text overlay: [Any text appearing on screen]

SCENE 2 — REAL-LIFE CONNECTION (0:30 - 1:00)
On-screen: [Relatable Indian scenario — market, cricket, cooking, etc.]
Narration: [Connect topic to daily Indian life]

SCENE 3 — CONCEPT INTRODUCTION (1:00 - 3:00)
On-screen: [Animated explanation of core concept]
Narration: [Clear, simple explanation]
Key term highlighted: [Important words bolded on screen]

SCENE 4 — EXAMPLE 1 — EASY (3:00 - 4:30)
On-screen: [Step-by-step solved example]
Narration: [Talk through each step]
NCERT connection: [Reference specific NCERT example]

SCENE 5 — EXAMPLE 2 — MEDIUM (4:30 - 5:30)
On-screen: [Slightly harder example]
Narration: [Build on previous concept]

SCENE 6 — REAL-WORLD APPLICATION (5:30 - 6:30)
On-screen: [How this is used in real life]
Narration: [Why this matters beyond exams]

SCENE 7 — RECAP + NEXT STEPS (6:30 - 7:00)
On-screen: [3-point visual summary]
Narration: "Remember these 3 things..."
CTA: "Now practice with 5 quick questions!"

---

ANIMATION NOTES FOR PRODUCTION TEAM:
- Character skin tones: [Specify mix for diversity]
- Setting: [Classroom / Home / Outdoor / Abstract]
- Color scheme: EduBharat palette (blues + saffron + white)
- Font: Noto Sans for text overlays
- Background music: Upbeat Indian-fusion instrumental, low volume
```

---

## Template 2: Practice Question Format

```
QUESTION TEMPLATE
================
Platform: EduBharat
Class: [6 / 7 / 8]
Subject: [Subject]
Chapter: [Chapter number and name]
Topic: [Specific topic]
Difficulty: [Easy / Medium / Hard]
Question Type: [MCQ / Fill-in-the-blank / True-False / Match / Numerical]
Learning Outcome Mapped: [LO1 / LO2 / LO3]
NCERT Source: [Exercise X.X, Q.X OR Exemplar OR Original]

QUESTION:
[Write the complete question here. For Indian context, use Indian names (Rahul, Priya, Kavita, Arjun) and Indian settings (mela, bazaar, cricket, Diwali)]

OPTIONS: (for MCQ only)
A) [Option]
B) [Option]
C) [Option — common misconception]
D) [Option — common misconception]

CORRECT ANSWER: [A/B/C/D or the correct value]

EXPLANATION:
[Full step-by-step explanation of HOW to arrive at the answer]
[For wrong options: explain WHY they are wrong — addresses common mistakes]

HINT (Level 1 — vague): [Give a direction without revealing answer]
HINT (Level 2 — medium): [Give a more specific pointer]
HINT (Level 3 — specific): [Give the first step of the solution]

TAGS: [chapter_name, topic, difficulty, board_relevant, exam_type]
```

---

## Template 3: Chapter Summary Card (PDF/Infographic)

```
CHAPTER SUMMARY CARD TEMPLATE
==============================
Size: A4 landscape (for printing) / 800x600px (for screen)
Design: EduBharat brand colors, Noto Sans font

TOP BAR: Subject name | Class | Chapter number and name

SECTION 1 — WHAT YOU LEARNED (LEFT COLUMN, 40%)
• 3-5 key concepts in bullet points
• One visual/diagram per concept (simple, hand-drawn style)

SECTION 2 — KEY FORMULAS/RULES (CENTER, 30%)
• All formulas in a highlighted box (saffron background)
• In both English and Hindi (toggle on digital version)

SECTION 3 — REMEMBER THIS! (RIGHT COLUMN, 30%)
• Most common mistakes to avoid
• 2-3 memory tricks / mnemonics
• NCERT exercise page reference

BOTTOM BAR:
• "Practice now →" CTA
• EduBharat logo + chapter number
• "Downloaded from EduBharat — Free for students"
```

---

## Template 4: Coding Module (Scratch — Class 6)

```
CODING LESSON TEMPLATE
======================
Platform: EduBharat
Class: 6
Module: Coding — Scratch
Lesson: [Lesson number and name]
Duration: 20-30 minutes
Prerequisite: [Previous lesson]

LEARNING OUTCOME:
By end of this lesson, student can: [What they can build/do]

STORY CONTEXT (make it relatable):
[Frame the coding activity in an Indian story — e.g., "Help Meena's fruit stall calculate change automatically"]

STEP 1 — WATCH (5 min):
[Link to 5-min animated video showing what they'll build]

STEP 2 — FOLLOW ALONG (10 min):
[Step-by-step instructions using Scratch interface]
Instruction 1: [Exact block to drag, what to set it to]
Instruction 2: [Continue...]
[Include screenshot descriptions at key steps]

STEP 3 — BUILD IT YOURSELF (10 min):
[Mini-challenge using same concepts but different scenario]
"Now try this: Instead of Meena's stall, make the same program for a cricket score counter"

STEP 4 — SHARE + CELEBRATE:
[Submit button → auto-graded for completion]
[Badge unlocked: "Coder Level 1" or similar]

NEXT LESSON PREVIEW:
"In the next lesson, you'll make your sprite move using arrow keys..."
```

---

## Template 5: Teacher Homework Assignment

```
HOMEWORK ASSIGNMENT TEMPLATE
============================
[Teachers use this format when assigning via EduBharat Teacher Dashboard]

Assignment Title: [e.g., "Chapter 7 Fractions Practice"]
Class: [6A / 7B / etc.]
Subject: [Maths]
Assigned by: [Teacher name]
Due Date: [Date + Time]

CONTENT ASSIGNED:
□ Watch: Video — "Understanding Fractions" (7 min)
□ Practice: Chapter 7 Quiz — 10 questions (adaptive difficulty)
□ Optional: Bonus Challenge — "Fraction Word Problems"

INSTRUCTIONS FOR STUDENTS:
[Teacher's personal note — free text field]
"Please complete the video before attempting the quiz. We'll discuss results in class on [day]."

GRADING:
□ Auto-graded (results show immediately)
□ Manual review needed (for open-ended questions)

PARENT NOTIFICATION: [Yes / No — sends WhatsApp to linked parent number]

REMINDER: [1 day before / Day of / No reminder]
```
