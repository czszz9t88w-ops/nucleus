# EduBharat — NCERT Curriculum Map (Class 6-8)
*Status: [FINAL] | Source: NCERT Official | Last updated: May 2026*

---

## CLASS 6

### Mathematics (NCERT)
| Ch# | Chapter Name | Key Concepts | Videos Needed | Questions Needed |
|----|-------------|-------------|--------------|----------------|
| 1 | Knowing Our Numbers | Large numbers, estimation, Roman numerals | 3 | 25 |
| 2 | Whole Numbers | Number line, properties of whole numbers | 2 | 20 |
| 3 | Playing with Numbers | Factors, multiples, LCM, HCF | 4 | 30 |
| 4 | Basic Geometrical Ideas | Points, lines, curves, polygons | 3 | 20 |
| 5 | Understanding Elementary Shapes | 2D shapes, 3D shapes, angles | 3 | 25 |
| 6 | Integers | Negative numbers, number line, operations | 3 | 25 |
| 7 | Fractions | Types, comparison, operations | 4 | 30 |
| 8 | Decimals | Place value, operations, applications | 3 | 25 |
| 9 | Data Handling | Data collection, tally, bar graphs | 2 | 20 |
| 10 | Mensuration | Perimeter, area of simple shapes | 3 | 25 |
| 11 | Algebra | Variables, expressions, simple equations | 3 | 25 |
| 12 | Ratio and Proportion | Ratio, proportion, unitary method | 3 | 25 |
| 13 | Symmetry | Line of symmetry, reflection | 2 | 15 |
| 14 | Practical Geometry | Compass constructions | 2 | 15 |
| **TOTAL** | | | **40 videos** | **325 questions** |

### Science (NCERT)
| Ch# | Chapter Name | Key Concepts | Videos Needed | Questions Needed |
|----|-------------|-------------|--------------|----------------|
| 1 | Food: Where Does It Come From? | Plant/animal sources, food chain | 2 | 20 |
| 2 | Components of Food | Nutrients, balanced diet, deficiency diseases | 2 | 20 |
| 3 | Fibre to Fabric | Natural fibres, spinning, weaving | 2 | 15 |
| 4 | Sorting Materials into Groups | Properties of materials | 2 | 20 |
| 5 | Separation of Substances | Methods of separation | 3 | 25 |
| 6 | Changes Around Us | Reversible/irreversible changes | 2 | 20 |
| 7 | Getting to Know Plants | Parts of plant, functions | 3 | 25 |
| 8 | Body Movements | Joints, bones, movement in animals | 2 | 20 |
| 9 | The Living Organisms | Characteristics of living things, habitats | 2 | 20 |
| 10 | Motion and Measurement | Distance, units, types of motion | 3 | 25 |
| 11 | Light, Shadows and Reflections | Transparent/opaque, shadow, reflection | 2 | 20 |
| 12 | Electricity and Circuits | Electric circuit, conductors | 3 | 25 |
| 13 | Fun with Magnets | Properties of magnets | 2 | 20 |
| 14 | Water | Water cycle, water conservation | 2 | 20 |
| 15 | Air Around Us | Composition of air, importance | 2 | 20 |
| 16 | Garbage In, Garbage Out | Waste management, composting | 2 | 15 |
| **TOTAL** | | | **36 videos** | **330 questions** |

---

## CLASS 7

### Mathematics (NCERT)
| Ch# | Chapter Name | Videos Needed | Questions Needed |
|----|-------------|--------------|----------------|
| 1 | Integers | 3 | 25 |
| 2 | Fractions and Decimals | 4 | 30 |
| 3 | Data Handling | 3 | 25 |
| 4 | Simple Equations | 3 | 25 |
| 5 | Lines and Angles | 3 | 25 |
| 6 | The Triangle and Its Properties | 4 | 30 |
| 7 | Congruence of Triangles | 3 | 25 |
| 8 | Comparing Quantities | 4 | 30 |
| 9 | Rational Numbers | 4 | 30 |
| 10 | Practical Geometry | 2 | 20 |
| 11 | Perimeter and Area | 3 | 25 |
| 12 | Algebraic Expressions | 4 | 30 |
| 13 | Exponents and Powers | 3 | 25 |
| 14 | Symmetry | 2 | 20 |
| 15 | Visualising Solid Shapes | 2 | 20 |
| **TOTAL** | | **47 videos** | **385 questions** |

### Science (NCERT)
| Ch# | Chapter Name | Videos Needed | Questions Needed |
|----|-------------|--------------|----------------|
| 1 | Nutrition in Plants | 3 | 25 |
| 2 | Nutrition in Animals | 3 | 25 |
| 3 | Fibre to Fabric | 2 | 20 |
| 4 | Heat | 3 | 25 |
| 5 | Acids, Bases and Salts | 3 | 25 |
| 6 | Physical and Chemical Changes | 3 | 25 |
| 7 | Weather, Climate and Adaptations | 2 | 20 |
| 8 | Winds, Storms and Cyclones | 2 | 20 |
| 9 | Soil | 2 | 20 |
| 10 | Respiration in Organisms | 3 | 25 |
| 11 | Transportation in Animals and Plants | 3 | 25 |
| 12 | Reproduction in Plants | 3 | 25 |
| 13 | Motion and Time | 3 | 25 |
| 14 | Electric Current and Its Effects | 3 | 25 |
| 15 | Light | 3 | 25 |
| 16 | Water: A Precious Resource | 2 | 20 |
| 17 | Forests: Our Lifeline | 2 | 20 |
| 18 | Wastewater Story | 2 | 20 |
| **TOTAL** | | **46 videos** | **415 questions** |

---

## CLASS 8

### Mathematics (NCERT)
| Ch# | Chapter Name | Videos Needed | Questions Needed |
|----|-------------|--------------|----------------|
| 1 | Rational Numbers | 4 | 30 |
| 2 | Linear Equations in One Variable | 4 | 30 |
| 3 | Understanding Quadrilaterals | 4 | 30 |
| 4 | Practical Geometry | 2 | 20 |
| 5 | Data Handling | 3 | 25 |
| 6 | Squares and Square Roots | 4 | 30 |
| 7 | Cubes and Cube Roots | 3 | 25 |
| 8 | Comparing Quantities | 4 | 30 |
| 9 | Algebraic Expressions and Identities | 4 | 30 |
| 10 | Visualising Solid Shapes | 2 | 20 |
| 11 | Mensuration | 4 | 30 |
| 12 | Exponents and Powers | 3 | 25 |
| 13 | Direct and Inverse Proportions | 3 | 25 |
| 14 | Factorisation | 4 | 30 |
| 15 | Introduction to Graphs | 3 | 25 |
| 16 | Playing with Numbers | 2 | 20 |
| **TOTAL** | | **53 videos** | **425 questions** |

---

## GRAND TOTAL — Content Required (All Classes, Maths + Science)

| | Class 6 | Class 7 | Class 8 | TOTAL |
|--|---------|---------|---------|-------|
| Maths Videos | 40 | 47 | 53 | **140** |
| Science Videos | 36 | 46 | ~50 | **132** |
| Maths Questions | 325 | 385 | 425 | **1,135** |
| Science Questions | 330 | 415 | ~430 | **1,175** |
| **Total Videos** | **76** | **93** | **~103** | **~272** |
| **Total Questions** | **655** | **800** | **~855** | **~2,310** |

**Phase 1 Focus (Class 6 only):** 76 videos + 655 questions
**Estimated Production Time:** 4 months (video) | 6 weeks (questions)

---

## Social Science Coverage

### History (Our Pasts)
- Class 6: What Where How When, On The Trail of the Earliest People, Kingdoms Kings and Early Republic, New Empires and Kingdoms (8 chapters)
- Class 7: Tracing Changes Through 1000 Years, New Kings and Kingdoms, Delhi Sultans, Mughal Empire (10 chapters)
- Class 8: How When and Where, From Trade to Territory, Ruling the Countryside, Civilising Mission (12 chapters)

### Geography (The Earth: Our Habitat / Our Environment / Resources and Development)
- Class 6: The Earth in Solar System, Globe, Latitudes and Longitudes, Maps, Major Landforms, Major Domains, India Climate Vegetation Wildlife (8 chapters)
- Class 7: Environment, Inside the Earth, Rocks, Air, Water, Natural Vegetation and Wildlife (9 chapters)
- Class 8: Resources, Land Soil Water Natural Vegetation and Wildlife, Mineral and Power Resources, Agriculture, Industries, Human Resources (6 chapters)

### Civics (Social and Political Life)
- Class 6: Understanding Diversity, Government, Constitutional Values, Parliamentary Government, Panchayati Raj, Rural Local Government, Urban Local Government (9 chapters)
- Class 7: On Equality, Health, State Government, Growing up as boys and girls, Women change the world, Understanding Media, Understanding Advertising, Markets Around Us, Market and a Social Institution (9 chapters)
- Class 8: The Indian Constitution, Understanding Secularism, Why Do We Need a Parliament, Understanding Laws, Judiciary, Understanding Our Criminal Justice System, Understanding Marginalisation, Confronting Marginalisation, Public Facilities, Law and Social Justice (10 chapters)
