# 💰 EduBharat — Business Model & Go-To-Market Strategy

---

## 1. Pricing Model (Freemium)

### Tier Comparison

| Feature | 🆓 Free | 💛 EduBharat Plus (₹299/mo) | 🏫 School License |
|---------|--------|---------------------------|------------------|
| Video capsules | 3/day per subject | Unlimited | Unlimited |
| Practice questions | 5 per chapter | Unlimited | Unlimited |
| Adaptive difficulty | Basic (3 levels) | Full adaptive engine | Full adaptive engine |
| Chapter tests | 1 per chapter | Unlimited attempts | Unlimited |
| Sample papers | 1 free paper | All papers + solutions | All papers |
| AI Doubt Solver | ❌ | ✅ Unlimited | ✅ Unlimited |
| Offline downloads | ❌ | ✅ 5 capsules | ✅ Unlimited |
| Leaderboard | Class only | National + Class | School-wide |
| Badge system | Basic badges | All badges + exclusive Plus badges | All badges |
| Parent dashboard | Weekly summary only | Full real-time dashboard | Full dashboard |
| Teacher tools | ❌ | ❌ | ✅ Full portal |
| Analytics | ❌ | Personal only | Class + individual |
| Low-data mode | ✅ | ✅ | ✅ |
| Ads | None | None | None |

### Pricing Rationale
- **₹299/month = ₹3,588/year** — far below Byju's (₹30,000–1,00,000/year)
- Comparable to a single tuition session with a local tutor
- Family plan: ₹499/month for up to 3 children (upsell for Phase 2)
- Annual plan: ₹2,499/year (₹208/month — 30% discount, improves LTV)

### School Licensing
- **Per student rate**: ₹150/student/year (minimum 100 students)
- **Per school**: Starting ₹15,000/year for up to 100 students
- **Includes**: Teacher portal, school analytics, custom branding option
- **Government school rate**: ₹75/student (50% discount + CSR eligibility)

---

## 2. Revenue Model (Year 1 Projections)

| Stream | Target Users | ARPU | Annual Revenue |
|--------|-------------|------|----------------|
| Free (base) | 50,000 | ₹0 | ₹0 |
| EduBharat Plus | 5,000 (10% conversion) | ₹2,499 | ₹1.25 Cr |
| School licenses | 20 schools × 200 students | ₹150/student | ₹6 Lakh |
| **Year 1 Total** | | | **~₹1.3 Cr** |

Year 2 target: 5 lakh free users → 50,000 Plus subscribers → ₹12.5 Cr ARR

---

## 3. Go-To-Market Strategy

### Phase 1: Direct to Student (D2C)
**Target**: Delhi NCR, Noida, Ghaziabad, Gurgaon + digital reach

**Channels**:
- WhatsApp groups (parent communities, school WhatsApp groups)
- YouTube (short 2-min sample lessons — "Class 6 Maths Chapter 1 explained in 5 minutes")
- Instagram Reels (quick concept explanations, exam tips)
- Facebook Groups (parent groups for CBSE schools)
- Google Ads targeting "NCERT solutions class 6", "class 6 maths online"

**Launch Hook**: "Get full Class 6 Maths free — forever" (loss leader to build base)

### Phase 2: School B2B
**Target**: Private CBSE schools, Tier 1 + Tier 2 cities

**Approach**:
1. Partner with 5 schools in NCR as reference customers (free or heavily discounted)
2. Get teacher testimonials + student outcome data
3. Build case study + deck for school principal pitches
4. Hire 2 school relationship managers (field sales, Delhi + Mumbai)
5. Attend school principal associations and education conferences

### Phase 3: Government & NGO Partnerships
- Apply to DIKSHA content partnership (contribute content to govt platform, get brand visibility)
- Apply to PM e-VIDYA programme
- CSR partnerships with IT companies (Infosys, TCS, Wipro have education CSR mandates)

---

## 4. Marketing Content Calendar (Month 1–3)

| Week | Content | Platform | Goal |
|------|---------|----------|------|
| W1 | "Why Class 6 is the most important year" | Instagram + Facebook | Awareness |
| W2 | Class 6 Maths Chapter 1 — free sample video | YouTube | Trust + Signup |
| W3 | "Study without stress — NEP 2020 explained for parents" | Facebook Groups | Parent trust |
| W4 | First 100 users leaderboard reveal | Instagram Stories | Social proof |
| W5 | Science experiment animation preview | YouTube Shorts | Engagement |
| W6 | Student testimonial (from pilot schools) | Instagram Reels | Trust |
| W7 | "Hindi mein padho, marks badhao" campaign | Facebook + WhatsApp | Hindi tier |
| W8 | Teacher spotlight: How EduBharat helps teachers | LinkedIn | B2B signal |
| W9 | Diwali special: 7-day streak challenge | All channels | Re-engagement |
| W10 | 1,000 students milestone celebration | All channels | PR + virality |
| W11 | Parent guide: How to track your child's progress | Email newsletter | Retention |
| W12 | Phase 1 → Phase 2 announcement | All channels | Anticipation |

---

## 5. Key Metrics to Track

| Metric | Target (Month 3) | Target (Month 6) |
|--------|-----------------|-----------------|
| Registered users | 10,000 | 50,000 |
| DAU (Daily Active Users) | 2,000 (20%) | 15,000 (30%) |
| Average session duration | 18 minutes | 22 minutes |
| 7-day streak retention | 25% | 35% |
| Free → Plus conversion | 5% | 10% |
| School partnerships | 3 | 15 |
| NPS score | 50+ | 65+ |
| Videos completed per user/week | 5 | 8 |
| Practice questions answered/day | 10,000 | 60,000 |

---

## 6. Funding Strategy (If Seeking Investment)

### Bootstrap Phase (Month 1–6)
- Self-funded MVP with lean team
- Target: 10,000 users and 3 school partnerships as proof points

### Seed Round (Month 6–9)
- Target: ₹1–2 Crore seed funding
- Use: Content production (video team), engineering (3 devs), marketing (₹30L)
- Target investors: Angel investors from EdTech/SaaS background, India-focused micro VCs

### Series A (Month 15–18)
- Target: ₹5–10 Crore
- Trigger: 1 lakh MAU + ₹50L ARR + 3 state partnerships
- Use: National expansion, regional language content, teacher marketplace
