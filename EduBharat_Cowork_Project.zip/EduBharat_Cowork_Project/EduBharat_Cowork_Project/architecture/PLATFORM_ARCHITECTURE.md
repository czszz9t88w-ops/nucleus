# 🏗️ EduBharat — Platform Architecture & Feature Specifications

---

## 1. Platform Overview

| Item | Decision |
|------|----------|
| Platform Type | Web App (PWA) + Native Android App (Phase 3) |
| Frontend Framework | Next.js 14 (React) + Tailwind CSS |
| Mobile Strategy | PWA first → Play Store app in Phase 3 |
| Backend | Node.js + PostgreSQL + Redis |
| Video Hosting | CDN (Cloudflare Stream or AWS CloudFront) |
| AI/ML | Anthropic Claude API (doubt solver, chatbot, adaptive engine) |
| Authentication | Phone OTP (primary) + Google SSO (secondary) |
| Languages | Hindi + English (Phase 1), regional (Phase 3) |
| Offline | Service Worker + IndexedDB (5 videos + 3 practice sets) |

---

## 2. Sitemap (Full Platform)

```
EDUBHARAT
│
├── 🏠 Home / Landing Page
│   ├── Hero: "Learn Smarter, Score Higher"
│   ├── Subject previews (animated)
│   ├── Testimonials
│   ├── Free vs Plus comparison
│   └── School partnership CTA
│
├── 🔐 Auth
│   ├── Sign up (Phone OTP → Name → Class → Board → Language)
│   ├── Login
│   ├── Parent account linking
│   └── Teacher account (separate flow)
│
├── 📚 Student Dashboard (post-login)
│   ├── Today's Goal (streak + daily target)
│   ├── Continue Learning (resume last session)
│   ├── Subject Cards (Maths, Science, SST, English, Hindi, Coding)
│   ├── Weekly Challenge CTA
│   └── Leaderboard preview (class rank)
│
├── 📖 Subject → Chapter Map
│   ├── Visual level-map (game-style chapter progression)
│   ├── Chapter status: Locked / In Progress / Completed / Mastered
│   ├── Chapter preview card (click to open)
│   └── Overall subject progress ring
│
├── 🎬 Chapter Learning Flow
│   ├── Step 1: Concept Capsule (5–7 min video)
│   │   ├── Language toggle (Hindi / English)
│   │   ├── CC toggle (subtitles)
│   │   ├── Playback speed (0.75x / 1x / 1.25x / 1.5x)
│   │   └── Download for offline
│   ├── Step 2: Quick Check (3 MCQs, instant feedback)
│   ├── Step 3: Practice Set (10–15 questions, adaptive difficulty)
│   │   ├── Warm-Up Mode (easy, confidence-building)
│   │   ├── Sprint Mode (standard curriculum)
│   │   └── Race Mode (timed, adaptive hardness)
│   ├── Step 4: NCERT Solutions browser
│   └── Step 5: Chapter Summary Card (downloadable infographic)
│
├── 🏆 Gamification Hub
│   ├── My Streak (days counter + Streak Shield status)
│   ├── XP Progress Bar (to next level)
│   ├── Badge Wall (all earned + locked badges)
│   ├── Class Leaderboard (weekly reset)
│   ├── National Leaderboard (Phase 2)
│   └── Quiz Battle Arena
│       ├── vs AI opponent (always available)
│       └── Challenge a Friend (share link)
│
├── 🤖 Doubt Corner (Phase 2)
│   ├── Photo Doubt Solver (camera scan)
│   ├── AI Concept Chatbot (text Q&A)
│   ├── Doubt Feed (community Q&A, teacher-moderated)
│   └── Weekly Live Q&A (scheduled sessions)
│
├── 📊 My Progress
│   ├── Subject-wise completion %
│   ├── Strength heatmap (strong / average / weak topics)
│   ├── Time spent tracker (daily / weekly / monthly)
│   ├── Test score history
│   ├── XP and badge history
│   └── Download report (PDF)
│
├── 📝 Tests & Papers
│   ├── Chapter Tests (auto-generated)
│   ├── Sample Papers (CBSE pattern)
│   ├── Adaptive Practice Test (weak-topic focused)
│   └── Mock Exam (full syllabus, timed)
│
├── 💻 Coding Lab (Phase 2)
│   ├── Class 6: Scratch visual coding
│   ├── Class 7: Python blocks + logic puzzles
│   └── Class 8: Python text + mini projects
│
├── 🧪 Virtual Labs (Phase 2)
│   ├── Physics experiments
│   ├── Chemistry experiments
│   └── Biology diagrams + interactive models
│
├── 🎒 Beyond Books (Phase 3)
│   ├── Career Discovery Quiz
│   ├── Life Skills modules
│   └── Creative Arts activities
│
├── 👨‍👩‍👧 Parent Dashboard
│   ├── Child's weekly performance summary
│   ├── Weak topic alerts
│   ├── Daily usage time (with limits setting)
│   ├── Teacher messages
│   └── Subscription management
│
├── 👩‍🏫 Teacher Portal (Phase 2)
│   ├── Class management (add students)
│   ├── Assign homework (select chapter + due date)
│   ├── Class performance analytics
│   ├── Individual student reports
│   ├── Worksheet generator (download PDFs)
│   └── Custom test creator
│
└── ⚙️ Settings
    ├── Language preference (Hindi / English)
    ├── Low-data mode toggle
    ├── Offline downloads manager
    ├── Notification preferences
    └── Accessibility (font size, contrast mode)
```

---

## 3. Gamification Mechanics (Detailed)

### XP (Experience Points) System
| Action | XP Earned |
|--------|-----------|
| Complete a video capsule | +10 XP |
| Pass Quick Check (all correct) | +15 XP |
| Complete Practice Set | +20 XP |
| Complete a chapter | +50 XP |
| Daily login streak (7-day) | +100 XP bonus |
| Quiz Battle win vs AI | +25 XP |
| Quiz Battle win vs friend | +40 XP |
| Help a peer (Doubt Forum) | +15 XP |
| Perfect score on chapter test | +75 XP |
| Weekly Challenge completion | +150 XP |

### Streak System
- Streak = consecutive days with at least 1 completed activity
- **Streak Shield**: Earns 1 shield per 7-day streak; uses shield on missed day (streak protected)
- Max 2 shields held at any time
- Streak milestones: 7 days (Bronze), 30 days (Silver), 100 days (Gold), 365 days (Legendary)

### Levels (XP Thresholds)
```
Level 1:  0–100 XP       (Pathshala Shishya)
Level 2:  100–250 XP     (Jigyasu)
Level 3:  250–500 XP     (Vidyarthi)
Level 4:  500–1000 XP    (Prabuddha)
Level 5:  1000–2000 XP   (Gyaani)
Level 6:  2000–4000 XP   (Medhavi)
Level 7:  4000–8000 XP   (Scholar)
Level 8:  8000–15000 XP  (Acharya)
Level 9:  15000+ XP      (Vishvavidyalay Samrat)
```

### Badge Categories
- **Subject Badges**: Maths Star, Science Explorer, History Hunter, etc.
- **Speed Badges**: Lightning Solver, Quick Thinker, Speed Demon
- **Accuracy Badges**: Perfect Score, No Mistakes, Flawless Week
- **Streak Badges**: 7-Day, 30-Day, 100-Day, 365-Day streaks
- **Social Badges**: Helpful Peer, Team Player, Class Champion
- **Special Badges**: Diwali Learner, Independence Day Quiz, Weekend Warrior

---

## 4. Content Production Standards

### Video Capsule Spec
- **Duration**: 5–7 minutes (hard cap at 10 minutes)
- **Format**: Animated explanation (not talking head) — bright, colourful, NCERT-accurate
- **Audio**: Clear Hindi voice (primary) + English voice (secondary, toggle)
- **Subtitles**: Both Hindi and English CC tracks
- **Resolution**: 720p (download), 480p (streaming default)
- **Accessibility**: No red/green only distinctions; all text readable at small sizes

### Practice Question Standards
- Minimum 15 questions per chapter (MCQ + Application + HOTS mix)
- Each question: 3 difficulty levels (Easy / Medium / Hard)
- Every wrong answer: Specific error explanation (not just "incorrect")
- Every correct answer: Reinforcement message + concept link
- NCERT Exemplar questions integrated from Class 7 onward

### Chapter Summary Card Spec
- Visual infographic: A4 size, PDF downloadable
- Covers: Key concepts, Important formulas/dates/definitions, Common mistakes, Quick revision points
- Language: Bilingual (Hindi + English side by side)

---

## 5. Adaptive Engine Logic

```
Student answers Question → 
  IF correct AND answered fast → difficulty +1
  IF correct AND answered slow → difficulty unchanged
  IF incorrect with 1 hint → difficulty −1
  IF incorrect with 2+ hints → difficulty −2, flag as weak topic

Weak Topic Flag →
  Add to "Weak Topics" list
  Show in Progress Dashboard
  Include in next Adaptive Test
  Send to Parent Dashboard weekly report
  Prioritize in AI Doubt Corner recommendations
```

---

## 6. Tech Stack Detail

### Frontend
- **Framework**: Next.js 14 (App Router)
- **Styling**: Tailwind CSS + shadcn/ui components
- **State Management**: Zustand (lightweight, mobile-friendly)
- **Video Player**: Custom player built on Video.js (CC + speed + offline support)
- **Offline**: Service Worker (Workbox) + IndexedDB (Dexie.js)
- **Animations**: Framer Motion (gamification elements)
- **Charts**: Recharts (progress dashboards)
- **PWA**: next-pwa plugin

### Backend
- **Runtime**: Node.js (Express or Fastify)
- **Database**: PostgreSQL (primary) + Redis (sessions, leaderboard cache)
- **ORM**: Prisma
- **Auth**: Custom OTP (SMS via Twilio / MSG91) + JWT
- **File Storage**: AWS S3 (content assets)
- **Video CDN**: Cloudflare Stream or AWS CloudFront
- **AI Integration**: Anthropic Claude API (claude-sonnet-4-6 model)
- **Search**: Meilisearch (fast content search)

### DevOps
- **Hosting**: Vercel (frontend) + Railway or Render (backend)
- **CI/CD**: GitHub Actions
- **Monitoring**: Sentry (errors) + PostHog (analytics)
- **Testing**: Jest + Playwright (E2E)
