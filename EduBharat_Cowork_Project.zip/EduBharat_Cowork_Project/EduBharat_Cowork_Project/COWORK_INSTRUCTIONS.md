# 🎓 EduBharat — Cowork Project Instructions

## Who You Are Working With
You are assisting **Rishav** (based in Delhi/Noida) in building **EduBharat** — a digital learning platform for Class 6, 7, and 8 students under the Indian education system (NCERT/CBSE). This is a full product build, from research to launch.

---

## Project Goal
Build a research-backed, NEP 2020-aligned, gamified, bilingual (Hindi + English) EdTech web platform targeting the most underserved segment of Indian middle-school education — Class 6 to 8.

---

## How This Folder Is Organized

| Folder | Purpose |
|--------|---------|
| `01_Research/` | Market research, competitor analysis, NEP 2020 compliance notes |
| `02_Planning/` | Feature roadmap, business model, tech stack decisions |
| `03_Tasks/` | Actionable task lists by phase — Cowork executes from here |
| `04_Content_Structure/` | Subject/curriculum maps, content templates |
| `05_Design_References/` | UI/UX specs, color palette, wireframe notes |

---

## Priority Tasks for Cowork (Start Here)

1. **Read** `03_Tasks/PHASE1_TASKS.md` and begin executing tasks in order
2. **Reference** `01_Research/` files for context before creating any deliverable
3. **Output files** into the relevant folder (e.g., a competitor table → `01_Research/`)
4. **Ask for approval** before making any changes to files already marked `[FINAL]`
5. When unsure about an Indian curriculum detail, **check** `04_Content_Structure/curriculum_map.md` first

---

## Key Constraints
- All content must align with NCERT syllabus (CBSE board first, state boards later)
- Language: English primary, Hindi secondary — all key content must be bilingual
- Target device: Low-end Android phones (offline-first, PWA approach)
- Monetization: Freemium (generous free tier + ₹299/month premium)
- NEP 2020 compliance is mandatory — coding + life skills included from Phase 1

---

## Contact & Decision Maker
**Rishav** — Final approver on all design, content, and business decisions.
All files requiring decision → flag with `[NEEDS REVIEW]` tag.
