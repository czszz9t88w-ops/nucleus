# 📊 EduBharat — Research & Competitive Intelligence

> Source: Industry research conducted May 2026 | Claude-assisted market analysis

---

## 1. Market Opportunity

| Metric | Data | Source |
|--------|------|--------|
| K-12 students in India | 260 million+ | MHRD 2025 |
| India EdTech market size (2030) | $313 billion projected | IBEF |
| Schools adopting hybrid models | 82% as of 2025 | Eklavvya Report |
| Schools using AI-powered adaptive platforms | 15,000+ | Eklavvya Report |
| NEP 5+3+3+4 implementation | 67% of schools | Ministry of Education |
| Internet access in schools (2023-24) | 54% coverage | ASER 2024 |

**Key Insight**: Class 6–8 is the most underfunded and underserved segment in Indian EdTech.
Most platforms over-invest in Class 10/12 board preparation.

---

## 2. Competitor Analysis

### 2.1 DIKSHA (Government)
- **URL**: diksha.gov.in
- **Reach**: 80,000+ curriculum-linked content pieces in 15 languages
- **Strengths**: Free, NCERT-aligned, CBSE content for Grades 6–10, videos, quizzes, games, worksheets
- **Weaknesses**: Very outdated UX, near-zero engagement design, no gamification, poor mobile experience
- **Our Opportunity**: Match content breadth + dramatically better UX + gamification layer

### 2.2 Khan Academy
- **URL**: khanacademy.org
- **Reach**: Global, 135M+ registered learners
- **Strengths**: Adaptive mastery tracking — keeps showing different problem variations until concept sticks; free; structured skill trees
- **Weaknesses**: US-centric curriculum, limited Hindi content (expanding since 2022), no Indian board mapping
- **Our Opportunity**: Same adaptive intelligence + India-first curriculum + full Hindi support

### 2.3 Byju's
- **URL**: byjus.com
- **Reach**: 80M+ users, 3M+ paid subscribers
- **Strengths**: 50,000+ interactive videos, adaptive Warm Up / Sprint / Race modes, real-time progress reports, Class 4–12 coverage
- **Weaknesses**: Very expensive (₹30,000–1,00,000/year), extremely aggressive sales calls, offline limited, poor customer service
- **Our Opportunity**: Byju's-quality content at free/₹299 price point

### 2.4 Vedantu
- **URL**: vedantu.com
- **Reach**: 35M+ active users
- **Strengths**: Live 2-teacher model, real-time doubt solving, Class 6–12 CBSE/ICSE, 57 countries
- **Weaknesses**: Premium pricing (₹5,000–1,00,000 per course), internet-dependent, no true offline
- **Our Opportunity**: Live doubt solving + free tier + offline capability

### 2.5 Magnet Brains
- **URL**: magnetbrains.com
- **Reach**: 10M+ learners
- **Strengths**: 100% free, K-12 Hindi + English medium NCERT/CBSE, AI, Psychology, Entrepreneurship subjects
- **Weaknesses**: Video-only platform, minimal interactivity, no gamification, no adaptive learning
- **Our Opportunity**: Add interactivity + gamification + adaptive engine on top of free model

### 2.6 Meritnation
- **URL**: meritnation.com
- **Strengths**: Interactive exercises, live classes, multiple Indian boards, solutions database
- **Weaknesses**: Cluttered UX, paywall appears too early, limited regional language support
- **Our Opportunity**: Clean mobile-first UX + generous free tier

---

## 3. Industry Best Practices (UX + Engagement)

### 3.1 Gamification
- Points, badges, leaderboards, and interactive challenges proven to motivate learners
- **Critical warning**: Overly extrinsic-based systems (constant badge rewards) reduce long-term intrinsic motivation
- Best balance: Extrinsic rewards (badges) trigger intrinsic curiosity (desire to explore further)
- Kahoot!, ClassDojo used by schools for engagement — study this model

### 3.2 Microlearning
- Break content into 5–10 minute focused modules
- Each module: concept video → quick check → practice set → summary card
- Students 11–14 years: 10–15 min focused attention window
- Long lectures (45+ min) lose 60%+ of students before completion

### 3.3 Adaptive Learning
- AI-based adaptive learning customises difficulty in real-time
- NEP 2020 mandates PAL (Personalised Adaptive Learning) via AI through NDEAR
- Track: time on task, error patterns, hint usage → adjust difficulty
- Byju's "Race Mode" is a strong model to study

### 3.4 Social Learning
- Team challenges, peer Q&A, class leaderboards drive return visits
- Must be safe + moderated for the 11–14 age group
- No social media integration — self-contained platform community

### 3.5 Mobile + Offline First
- 82% hybrid model adoption → mobile is primary device
- Target: Low-end Android (2–3GB RAM, Android 8+), 2G/3G connectivity
- Build as PWA (Progressive Web App) — works without Play Store install
- Offline sync: up to 5 video capsules + 3 practice sets downloadable

---

## 4. NEP 2020 — Key Requirements for Class 6–8

| NEP Mandate | Platform Requirement | Priority |
|-------------|---------------------|----------|
| 5+3+3+4 structure (Middle = Class 6–8) | Age-appropriate UX, no JEE/NEET content here | Phase 1 |
| Competency-based learning | Topic mastery badges, not just exam scores | Phase 1 |
| Critical thinking integration | Socratic quiz mode, open-ended questions | Phase 1 |
| Coding from Class 6 | Scratch → Python block coding module | Phase 1 |
| Multilingual education | Hindi + English toggle; regional languages later | Phase 1 |
| Vocational exposure (Class 6+) | Career discovery module | Phase 2 |
| Experiential/activity learning | Virtual lab simulations | Phase 2 |
| Art + Life Skills | Creative arts, health, financial literacy | Phase 3 |
| Reduce rote learning | Activity-based + application questions dominate | Phase 1 |

---

## 5. User Research — Key Questions to Answer in Phase 1

Before building, conduct interviews using these questions:

**For Students (Class 6–8):**
1. What devices do you use for studying? (Phone / Tablet / Laptop / Desktop)
2. Do you use any apps or websites for studying? Which ones?
3. What do you find most boring about studying at home?
4. What subjects do you find hardest? Why?
5. Do you play mobile games? What do you like about them?
6. Would you use an app that makes studying feel like a game?
7. Do you prefer learning in Hindi or English?
8. Do you have internet at home? Is it fast or slow?

**For Teachers:**
1. Which EdTech tools do you currently use in class?
2. What's missing in existing platforms that would help your teaching?
3. Would you use a platform that lets you assign homework digitally?
4. How much time do students spend on screens vs books?
5. What subjects are most challenging for Class 6–8 students?

**For Parents:**
1. How much do you currently spend on tuition/coaching?
2. Would you pay ₹299/month for a quality learning app?
3. What concerns do you have about your child using a learning app?
4. Do you track your child's study habits? How?

---

## 6. Technology Benchmarks

| Capability | Best-in-Class Example | Target for EduBharat |
|------------|----------------------|---------------------|
| Video delivery | YouTube (adaptive bitrate) | CDN with 480p default, 720p for WiFi |
| Adaptive difficulty | Khan Academy exercise engine | 3-level difficulty per chapter |
| Gamification | Duolingo streak system | Daily streak + XP + badges |
| Offline support | Khan Academy app | Download up to 5 capsules |
| AI doubt solving | Photomath | Photo scan → step-by-step solution |
| Live doubt sessions | Vedantu | 2x weekly live Q&A per subject |
| Teacher tools | Google Classroom | Assign, track, grade + analytics |
