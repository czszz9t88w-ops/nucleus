# EduBharat — Session Handoff

## Goal We're Working Toward

Build EduBharat into the most efficient and high-quality online education portal for Class 6–8 Indian students — combining Byju's content quality, Khan Academy's adaptive intelligence, DIKSHA's free access, and NEP 2020-native design. Target: first Indian EdTech platform to serve the underserved Class 6–8 segment at ₹299/month with offline-first, voice-first, Hindi-first UX designed for the median ASER student (2–3 grades behind, shared Android phone, 2G/3G connectivity, Tier 2/3 India).

---

## Current State

**Planning complete — ready to begin development.**

All strategy, research, API selection, and implementation planning is done. No code has been written yet. The project exists as a structured documentation repository:

- Competitive analysis and market research complete
- Full platform architecture and feature specs defined
- Business model, pricing, and GTM strategy documented
- Class 6 curriculum map drafted
- 3-agent intelligence pipeline completed → validated feature list and phased roadmap produced
- Full implementation plan with free APIs written → `IMPLEMENTATION_PLAN.md`
- Free API stack researched and confirmed (Phase 1 cost: ~₹500–800/month)

**No codebase exists yet. Next step: scaffold the Next.js project and set up services.**

---

## Files Actively Being Worked On

| File | Status | Purpose |
|------|--------|---------|
| `IMPLEMENTATION_PLAN.md` | ✅ Complete (v1) | Full Phase 1–3 dev plan, all free APIs, code snippets, env vars, cost projection |
| `HANDOFF.md` | ✅ This file | Session continuity document |
| `architecture/PLATFORM_ARCHITECTURE.md` | ✅ Complete (v1) | Sitemap, feature specs, tech stack, gamification design |
| `architecture/BUSINESS_MODEL.md` | ✅ Complete (v1) | Pricing, revenue model, GTM, funding plan |
| `research/COMPETITIVE_ANALYSIS.md` | ✅ Complete (v1) | Competitor breakdown, market data, UX best practices |
| `curriculum/CLASS6_CURRICULUM_MAP.md` | ✅ Complete (v1) | Chapter-by-chapter content plan for Class 6 |
| `tasks/SPRINT1_NOW.md` | ⚠️ Needs update | Sprint 1 task list — update with Phase 1 sprint breakdown from IMPLEMENTATION_PLAN.md |
| `tasks/MASTER_TASKS.md` | ⚠️ Needs update | Full Phase 1–3 task list — align with validated 3-phase roadmap |

---

## 3-Agent Research Pipeline — Output This Session

A sequential 3-agent research pipeline was run and completed:

### Agent 1 (Feature Explorer) — Completed
Identified 15 features with source attribution and complexity ratings. Top 5 priority: Streak Engine, Microlearning Capsules + Placement Quiz, Offline PWA, Parent Dashboard, Camera Doubt Solver.

### Agent 2 (Online Analyst) — Completed
Validated, challenged, and enriched Agent 1's output. Scored 31/40 vs Agent 1's 20/40.

Key corrections made:
- Full ML adaptive engine → replace with rule-based mastery gates at MVP (too expensive to build from scratch)
- Camera Doubt Solver → API-first only (Mathpix + GPT-4V), not built from scratch
- Real-Time Quiz Arena → Async challenge format (real-time fails on 2G)
- Friend leaderboard → opt-in only (ASER: 66% of Class 8 below grade level = shame risk)
- NEP badge portfolio → internal gamification only, not shareable credential (ABC adoption <1%)
- Teacher network → simplified to "Share Class Code" at MVP

Added 5 new features Agent 1 missed:
1. Voice-First Vernacular AI Layer (Hindi TTS/ASR via AI4Bharat/SpeakX)
2. SEL Mood Check-In + Adaptive Content Routing
3. Near-Peer Study Buddy Cohort System
4. Lightweight Accessibility Mode (screen reader, ISL video)
5. "Explain It To Me" Bounded AI Clarification (GPT-4o, NCERT-scoped, Plus tier)

### Agent 3 (Verdict & Roadmap Judge) — Completed
Declared Agent 2 the winner. Produced the final validated roadmap (see below).

---

## Final Validated Roadmap

### Phase 1 — "Survive and Prove" (Month 1–3)
**North Star: 7-day streak retention rate → target 25%**

1. Offline-First PWA with Background Sync
2. Placement Quiz Onboarding (10-question diagnostic spanning 2–3 grade levels)
3. Microlearning Video Capsules — 90 at launch (3 subjects × 3 grades × 10 topics), bilingual, 5–7 min
4. Bilingual Hindi/English Per-Screen Toggle
5. Streak Engine with Burnout Guard (1 grace day per 7 days)
6. Visual Curriculum Roadmap (game-style node map)
7. Smart Push Notifications (capped at 1/day, behavioral triggers only)

### Phase 2 — "Grow and Retain" (Month 4–8)
**North Star: DAU/MAU ratio → target 30%**

8. Parent Dashboard + WhatsApp Weekly Report
9. Spaced Repetition Review Queue (FSRS algorithm)
10. Rule-Based Mastery Gating (80% accuracy → unlock next concept)
11. "Explain It To Me" Bounded AI Clarification (Plus tier, 10 queries/day cap)
12. Voice-First Vernacular AI Layer (Hindi TTS/ASR, API-first)
13. SEL Mood Check-In + Mood-Adaptive Content Routing
14. Teacher "Share Class Code" (lightweight flywheel)

### Phase 3 — "Scale and Differentiate" (Month 9–18)
**North Star: ARR → target ₹50 Lakh**

15. Camera AI Doubt Solver (Mathpix + GPT-4V, API-first, Plus only)
16. Near-Peer Study Buddy Cohort (density gate: 500 active users/grade/city)
17. Async Quiz Challenge Arena
18. Lightweight Accessibility Mode (screen reader, high contrast, ISL video)
19. NEP Competency Badge Portfolio (internal gamification only)
20. Full ML Adaptive Difficulty Engine (only after 12+ months data, 2L+ users)

---

## Everything That Was Tried / Decided Against

| Decision | Why Rejected / Deferred |
|----------|------------------------|
| Real-time multiplayer Quiz Arena at MVP | Fails on 2G/3G (30–40% packet loss); replaced with async challenge |
| Full ML adaptive engine at MVP | Too expensive and data-sparse; rule-based mastery gating is correct at this stage |
| Camera Doubt Solver built from scratch | Handwritten Devanagari OCR is a multi-year ML problem; use Mathpix + GPT-4V API |
| Default-on public leaderboard | ASER: 66% of Class 8 below grade level → public ranking is a shame engine for majority of users |
| Shareable NEP competency credentials | ABC adoption in schools <1%; no institutional ecosystem to receive badges yet |
| Full teacher portal at MVP | Too complex; simplified to "Share Class Code" only |
| Email-based parent reports | Indian parents use WhatsApp, not email; WhatsApp Business API is the correct channel |
| Launch all 6 subjects simultaneously | Content production cost is the real bottleneck; start with 3 subjects (Maths, Science, SST) |

---

## Monthly Cost Projections

| Phase | Users | Monthly Cost | Key Cost Drivers |
|-------|-------|-------------|-----------------|
| Phase 1 (MVP) | 0–10K | ~₹500–800 | Fast2SMS OTP only; everything else free |
| Phase 2 | 10K–50K | ~₹12,000–15,000 | Neon paid + Bunny Stream + Sarvam AI + WhatsApp BSP |
| Phase 3 | 50K–2L | ~₹40,000–50,000 | Full infra + Claude API paid + content team |

---

## Top 3 Risks to Watch

1. **Content production cost and velocity** — 90 launch capsules at ₹5,000 each ≈ ₹4.5L before first user. Plan and fund this from Day 1. Batch by chapter, not by subject.
2. **Gemini API rate limits at Plus scale** — 1,000 req/day free is fine for MVP; implement Upstash Redis semantic cache for common NCERT questions (est. 60–70% cache hit rate) before hitting the limit. Upgrade to Gemini paid tier at Phase 2.
3. **Social feature cold-start** — Near-Peer Cohort and Async Arena need user density. Do not launch until 500 active users per grade per city minimum. Treat as milestone-gated, not calendar-dated.

---

## India Compliance Checklist (Must Do Before Launch)

- [ ] **DLT registration** — register OTP SMS template with Fast2SMS (2–3 days; required by TRAI for all Indian SMS)
- [ ] **WhatsApp message template approval** — submit weekly report template to Meta (3–5 business days)
- [ ] **DPDP Act 2023 compliance** — Digital Personal Data Protection Act requires parental consent for minors (under 18). Add consent flow in onboarding.
- [ ] **Privacy Policy page** — required before Play Store submission and for Meta WhatsApp API approval
- [ ] **Terms of Service page** — required for App Store + investor diligence

---

## Next Steps to Take

### Immediate — Service Account Setup (Do Before Any Code)
- [ ] Sign up at **neon.tech** → create project `edubharat-prod` → copy `DATABASE_URL`
- [ ] Sign up at **console.firebase.google.com** → enable Auth (Google + Phone) + FCM → copy keys
- [ ] Sign up at **fast2sms.com** → add ₹100 wallet → register DLT OTP template (takes 2–3 days in India)
- [ ] Sign up at **mux.com** → create environment → copy `MUX_TOKEN_ID` + `MUX_TOKEN_SECRET`
- [ ] Sign up at **aistudio.google.com** → get `GEMINI_API_KEY` (free, no CC)
- [ ] Sign up at **console.groq.com** → get `GROQ_API_KEY` (free, no CC)
- [ ] Register at **bhashini.gov.in** → get `BHASHINI_API_KEY` (free for PoC)
- [ ] Sign up at **sarvam.ai** → activate startup program → get `SARVAM_API_KEY`
- [ ] Sign up at **upstash.com** → create Redis DB → copy URL + token
- [ ] Sign up at **resend.com** → get `RESEND_API_KEY`
- [ ] Sign up at **posthog.com** → get project key
- [ ] Sign up at **sentry.io** → get `SENTRY_DSN`
- [ ] Create **Cloudflare account** → enable R2 (CC needed, not charged) → create bucket `edubharat-assets`
- [ ] Deploy to **Cloudflare Pages** → connect GitHub repo

### Before Writing Code
- [ ] Conduct 5 student interviews (Class 6–8) — questions in `research/COMPETITIVE_ANALYSIS.md`
- [ ] Conduct 3 parent interviews — validate ₹299/month and WhatsApp report preference
- [ ] Update `tasks/SPRINT1_NOW.md` with Phase 1 sprint breakdown
- [ ] Update `tasks/MASTER_TASKS.md` to align with 3-phase roadmap
- [ ] Wireframe onboarding flow: Phone OTP → Name/Class → Language → Placement Quiz → First lesson → XP + Streak started

### Phase 1 Development Sequence (6 Sprints × 2 Weeks)
| Sprint | Deliverable |
|--------|-------------|
| Sprint 1 | Project scaffold (Next.js 14 + Prisma + Neon + Cloudflare Pages + PWA offline) |
| Sprint 2 | Auth flow (Firebase Auth + Fast2SMS OTP + onboarding + placement quiz) |
| Sprint 3 | Content player (Mux video + bilingual CC + Quick Check quiz + XP) |
| Sprint 4 | Streak engine + XP levels + curriculum roadmap UI (node map) |
| Sprint 5 | FCM push notifications + smart streak-rescue triggers |
| Sprint 6 | PostHog analytics + Sentry + launch checklist + first 30 videos uploaded |

### Content Production (Run in Parallel with Dev)
- [ ] Commission 30 Class 6 Maths videos (all chapters) — target: ready by Sprint 3
- [ ] Write 150 quiz questions (10/chapter × 15 chapters × 3 difficulty levels)
- [ ] Create 15 chapter summary PDFs (bilingual) — upload to Cloudflare R2
- [ ] Write Placement Quiz questions (10 per subject, spanning grades 4–7)

---

## Tech Stack (Confirmed + Free API Decisions)

| Layer | Service | Free Tier |
|-------|---------|-----------|
| Frontend | Next.js 14 (App Router) + Tailwind CSS + shadcn/ui | — |
| Hosting (frontend) | **Cloudflare Pages** | Unlimited bandwidth, commercial OK |
| Database | **Neon PostgreSQL** | 0.5 GB, no sleep penalty |
| Redis cache | **Upstash Redis** | 10,000 commands/day |
| Auth (social/email) | **Firebase Auth** | 50,000 MAU/month |
| Auth (OTP SMS) | **Fast2SMS** | ₹100 prepaid (~800 OTPs) |
| Video hosting | **Mux** (Phase 1) → **Bunny Stream** (Phase 2+) | 10 videos + 100K delivery min |
| Asset storage | **Cloudflare R2** | 10 GB + zero egress fees |
| AI tutor | **Google Gemini 2.5 Flash** | 1,000 req/day, no CC |
| Fast inference | **Groq (Llama 3.3 70B)** | 14,400 req/day, no CC |
| Hindi/regional AI | **Sarvam AI** | Signup credits + startup program (6–12 months) |
| Translation | **Bhashini API (Govt. India)** | Free for PoC/dev, 22 Indian languages |
| Vernacular (self-host) | **IndicTrans2 (AI4Bharat)** | Open source, MIT license |
| Push notifications | **Firebase Cloud Messaging** | Unlimited, forever free |
| Email | **Resend** | 3,000 emails/month |
| WhatsApp reports | **Meta WhatsApp Business API** | User-initiated = free |
| Analytics | **PostHog** | 1,000,000 events/month |
| Error tracking | **Sentry** | 5,000 errors/month |
| Search | **Meilisearch** (self-hosted) | Unlimited, MIT license |
| Math OCR | **Pix2Text** (self-hosted) | Unlimited, open source |
| ORM | Prisma | — |
| State management | Zustand | — |
| Offline | Workbox + Dexie.js (IndexedDB) | — |
| Animations | Framer Motion | — |
| Charts | Recharts | — |
| CI/CD | GitHub Actions | Free for public repos |

---

## Single Most Important Metric — Year 1

**7-day streak retention rate**

If EduBharat cannot get a student to return for 7 consecutive days, it has not formed a habit — it has sold a curiosity. Every other metric (revenue, word-of-mouth, school partnerships, investor narrative) is downstream of this number.

Target: **25% of registered users maintaining a 7-day streak by end of Month 3.**
If below 15%: stop growth spending, fix the core loop before scaling.

---

---

## Key Reference Files

| File | What to Read It For |
|------|---------------------|
| `IMPLEMENTATION_PLAN.md` | Full dev plan — code snippets, API setup, env vars, cost projection, launch checklist |
| `architecture/PLATFORM_ARCHITECTURE.md` | Sitemap, feature specs, gamification mechanics, adaptive engine logic |
| `architecture/BUSINESS_MODEL.md` | Pricing tiers, revenue model, GTM strategy, funding plan |
| `research/COMPETITIVE_ANALYSIS.md` | Competitor gaps, user interview questions, tech benchmarks |
| `curriculum/CLASS6_CURRICULUM_MAP.md` | Chapter-by-chapter content plan for Class 6 |

---

*Last updated: May 2026 | Session: Strategy + 3-Agent Pipeline + Implementation Plan + Free API Stack*
