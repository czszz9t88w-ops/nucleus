# 📖 EduBharat — Curriculum Map: Class 6 (Phase 1)

> NCERT/CBSE aligned | Phase 1 launch content

---

## MATHEMATICS — Class 6

| Ch # | Chapter Name | Key Concepts | Content Status |
|------|-------------|--------------|----------------|
| 1 | Knowing Our Numbers | Large numbers, Indian/International system, estimation | ⬜ To Script |
| 2 | Whole Numbers | Number line, properties of whole numbers | ⬜ To Script |
| 3 | Playing with Numbers | Factors, multiples, HCF, LCM, prime factorisation | ⬜ To Script |
| 4 | Basic Geometrical Ideas | Point, line, angle, triangle, quadrilateral, circle | ⬜ To Script |
| 5 | Understanding Elementary Shapes | Angles, triangles, polygons, 3D shapes | ⬜ To Script |
| 6 | Integers | Negative numbers, number line, addition/subtraction of integers | ⬜ To Script |
| 7 | Fractions | Types of fractions, equivalent, comparison, operations | ⬜ To Script |
| 8 | Decimals | Place value, comparison, operations on decimals | ⬜ To Script |
| 9 | Data Handling | Tally marks, pictograph, bar graph | ⬜ To Script |
| 10 | Mensuration | Perimeter, area of rectangles and squares | ⬜ To Script |
| 11 | Algebra | Introduction to variables, expressions, simple equations | ⬜ To Script |
| 12 | Ratio and Proportion | Ratio, proportion, unitary method | ⬜ To Script |
| 13 | Symmetry | Line of symmetry, rotational symmetry | ⬜ To Script |
| 14 | Practical Geometry | Construction using compass, ruler | ⬜ To Script |

**Content per chapter**: 1 intro video (6 min) + 1 deep dive video (8 min) + 15 practice questions + NCERT solutions + Summary card

---

## SCIENCE — Class 6

| Ch # | Chapter Name | Key Concepts | Content Status |
|------|-------------|--------------|----------------|
| 1 | Food: Where Does It Come From? | Plant/animal sources, herbivores/carnivores/omnivores | ⬜ To Script |
| 2 | Components of Food | Nutrients, balanced diet, deficiency diseases | ⬜ To Script |
| 3 | Fibre to Fabric | Natural fibres, plant fibres, cotton and jute | ⬜ To Script |
| 4 | Sorting Materials Into Groups | Properties of materials, transparent/opaque | ⬜ To Script |
| 5 | Separation of Substances | Methods of separation (sieving, filtration, evaporation) | ⬜ To Script |
| 6 | Changes Around Us | Reversible/irreversible changes | ⬜ To Script |
| 7 | Getting to Know Plants | Parts of plants, root/stem/leaf/flower functions | ⬜ To Script |
| 8 | Body Movements | Types of joints, skeletal system, locomotion in animals | ⬜ To Script |
| 9 | The Living Organisms and Their Surroundings | Habitat, adaptation, biotic/abiotic components | ⬜ To Script |
| 10 | Motion and Measurement of Distances | Standard units, types of motion | ⬜ To Script |
| 11 | Light, Shadows and Reflections | Transparent/opaque, shadows, reflection | ⬜ To Script |
| 12 | Electricity and Circuits | Electric cell, bulb, circuit, conductors/insulators | ⬜ To Script |
| 13 | Fun with Magnets | Magnetic materials, poles, compass | ⬜ To Script |
| 14 | Water | Sources, water cycle, conservation | ⬜ To Script |
| 15 | Air Around Us | Composition of air, importance | ⬜ To Script |
| 16 | Garbage In, Garbage Out | Waste management, composting, recycling | ⬜ To Script |

---

## SOCIAL SCIENCE — Class 6 (Phase 1 partial)

### History: Our Pasts — I
| Ch # | Chapter Name | Content Status |
|------|-------------|----------------|
| 1 | What, Where, How and When? | ⬜ To Script |
| 2 | On The Trail of the Earliest People | ⬜ To Script |
| 3 | From Gathering to Growing Food | ⬜ To Script |
| 4 | In the Earliest Cities | ⬜ To Script |
| 5 | What Books and Burials Tell Us | ⬜ To Script |
| 6 | Kingdoms, Kings and An Early Republic | ⬜ To Script |
| 7 | New Questions and Ideas | ⬜ To Script |
| 8 | Ashoka, The Emperor Who Gave Up War | ⬜ To Script |
| 9 | Vital Villages, Thriving Towns | ⬜ To Script |
| 10 | Traders, Kings and Pilgrims | ⬜ To Script |
| 11 | New Empires and Kingdoms | ⬜ To Script |
| 12 | Buildings, Paintings and Books | ⬜ To Script |

### Geography: The Earth Our Habitat
| Ch # | Chapter Name | Content Status |
|------|-------------|----------------|
| 1 | The Earth in the Solar System | ⬜ To Script |
| 2 | Globe: Latitudes and Longitudes | ⬜ To Script |
| 3 | Motions of the Earth | ⬜ To Script |
| 4 | Maps | ⬜ To Script |
| 5 | Major Domains of the Earth | ⬜ To Script |
| 6 | Major Landforms of the Earth | ⬜ To Script |
| 7 | Our Country — India | ⬜ To Script |
| 8 | India: Climate, Vegetation and Wildlife | ⬜ To Script |

### Civics: Social and Political Life — I
| Ch # | Chapter Name | Content Status |
|------|-------------|----------------|
| 1 | Understanding Diversity | ⬜ To Script |
| 2 | Diversity and Discrimination | ⬜ To Script |
| 3 | What is Government? | ⬜ To Script |
| 4 | Key Elements of a Democratic Government | ⬜ To Script |
| 5 | Panchayati Raj | ⬜ To Script |
| 6 | Rural Administration | ⬜ To Script |
| 7 | Urban Administration | ⬜ To Script |
| 8 | Rural Livelihoods | ⬜ To Script |
| 9 | Urban Livelihoods | ⬜ To Script |

---

## ENGLISH — Class 6

### Honeysuckle (Main Reader)
| Ch # | Title | Genre | Content Status |
|------|-------|-------|----------------|
| 1 | Who Did Patrick's Homework? | Story | ⬜ To Script |
| 2 | How the Dog Found Himself a New Master! | Story | ⬜ To Script |
| 3 | Taro's Reward | Story | ⬜ To Script |
| 4 | An Indian-American Woman in Space | Biography | ⬜ To Script |
| 5 | A Different Kind of School | Story | ⬜ To Script |
| 6 | Who I Am | Narrative | ⬜ To Script |
| 7 | Fair Play | Story | ⬜ To Script |
| 8 | A Game of Chance | Story | ⬜ To Script |
| 9 | Desert Animals | Information | ⬜ To Script |
| 10 | The Banyan Tree | Story | ⬜ To Script |

---

## HINDI — Class 6

### Vasant — Part 1
| Ch # | Title | Content Status |
|------|-------|----------------|
| 1 | वह चिड़िया जो | ⬜ To Script |
| 2 | बचपन | ⬜ To Script |
| 3 | नादान दोस्त | ⬜ To Script |
| 4 | चाँद से थोड़ी-सी गप्पें | ⬜ To Script |
| 5 | अक्षरों का महत्व | ⬜ To Script |
| 6 | पार नज़र के | ⬜ To Script |
| 7 | साथी हाथ बढ़ाना | ⬜ To Script |
| 8 | ऐसे–ऐसे | ⬜ To Script |
| 9 | टिकट-अलबम | ⬜ To Script |
| 10 | झाँसी की रानी | ⬜ To Script |
| 11 | जो देखकर भी नहीं देखते | ⬜ To Script |
| 12 | संसार पुस्तक है | ⬜ To Script |
| 13 | मैं सबसे छोटी होऊँ | ⬜ To Script |
| 14 | लोकगीत | ⬜ To Script |
| 15 | नौकर | ⬜ To Script |
| 16 | वन के मार्ग में | ⬜ To Script |
| 17 | साँस-साँस में बाँस | ⬜ To Script |

---

## CODING — Class 6 (NEP 2020 Add-on)

### Scratch Visual Coding — Module Plan
| Module # | Topic | Learning Objective | Content Status |
|----------|-------|-------------------|----------------|
| 1 | Introduction to Scratch | Interface, sprites, stage | ⬜ To Build |
| 2 | Motion Blocks | Move, turn, go to | ⬜ To Build |
| 3 | Looks Blocks | Change costumes, say, think | ⬜ To Build |
| 4 | Events + Control | When clicked, wait, repeat | ⬜ To Build |
| 5 | Sensing + Operators | If-then, mouse/key sensing | ⬜ To Build |
| 6 | Variables | Create, set, change variable | ⬜ To Build |
| 7 | Mini Project: Animated Story | Apply all blocks in creative project | ⬜ To Build |
| 8 | Mini Project: Simple Game | Ball/paddle game using Scratch | ⬜ To Build |

---

## Content Priority for Phase 1 Launch

**Launch with this minimum viable content set:**

1. ✅ Class 6 Mathematics — ALL 14 chapters (video + practice + solutions)
2. ✅ Class 6 Science — ALL 16 chapters (video + practice + solutions)
3. ✅ Coding Module — Modules 1–4 (Scratch basics)
4. ⬜ Class 6 SST — History chapters 1–6 only
5. ⬜ Class 6 English — Honeysuckle chapters 1–5 only

Remaining subjects to be completed within 8 weeks post-launch.
