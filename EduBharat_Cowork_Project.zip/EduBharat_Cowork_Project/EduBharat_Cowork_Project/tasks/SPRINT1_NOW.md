# 🏃 EduBharat — Sprint 1 Task Board
## Weeks 1–2 | Research & Project Setup

> This is what to start working on RIGHT NOW in Cowork.

---

## 🔴 THIS WEEK (Week 1) — Foundation

### 1. Create Project Folder Structure on Your Computer
```
EduBharat/
├── 01_Research/
│   ├── User Interviews/
│   ├── Competitor Screenshots/
│   └── NEP 2020 Documents/
├── 02_Design/
│   ├── Wireframes/
│   ├── Brand Identity/
│   └── UI Designs/
├── 03_Content/
│   ├── Class6_Maths/
│   ├── Class6_Science/
│   └── Scripts/
├── 04_Tech/
│   ├── Frontend/
│   ├── Backend/
│   └── Database/
├── 05_Marketing/
│   ├── Social Media/
│   └── Content Calendar/
└── 06_Business/
    ├── Financials/
    └── Pitch Deck/
```
**Ask Cowork to**: Create this folder structure automatically on your Desktop

---

### 2. Brand Identity — Name & Logo
- [ ] Confirm platform name (EduBharat / suggestion: also consider "Vidya Setu" or "PadhAI")
- [ ] Create brand brief document:
  - Primary color: Deep teal (#1A5F8A) + Amber accent (#F5A623)
  - Tone: Friendly, energetic, Indian, trustworthy
  - Audience feel: "Like a brilliant older sibling teaching you"
- [ ] Ask Cowork to draft a Canva brief for logo design
- [ ] Ask Cowork to create color palette document in PDF

---

### 3. Competitor Research Folder
- [ ] Screenshot homepage of: DIKSHA, Khan Academy, Byju's, Vedantu, Magnet Brains
- [ ] Save screenshots in `01_Research/Competitor Screenshots/`
- [ ] Ask Cowork to create a competitor comparison table from this project's COMPETITIVE_ANALYSIS.md

---

### 4. User Interview Templates
- [ ] Ask Cowork to generate a Word document interview guide for students
- [ ] Ask Cowork to generate a Word document interview guide for teachers
- [ ] Ask Cowork to generate a Word document interview guide for parents
- [ ] Save all three in `01_Research/User Interviews/`

---

### 5. NEP 2020 Reference Files
- [ ] Download NEP 2020 PDF from education.gov.in
- [ ] Download NCERT Class 6 Maths PDF from ncert.nic.in
- [ ] Download NCERT Class 6 Science PDF from ncert.nic.in
- [ ] Save all in `01_Research/NEP 2020 Documents/`
- [ ] Ask Cowork to extract Chapter names and Learning Objectives from each PDF

---

## 🟡 NEXT WEEK (Week 2) — Design & Content Kickoff

### 6. Platform Sitemap Document
- [ ] Ask Cowork to create a formatted Word document sitemap from PLATFORM_ARCHITECTURE.md
- [ ] Save in `02_Design/`

### 7. Content Production Tracker
- [ ] Ask Cowork to create an Excel sheet from CLASS6_CURRICULUM_MAP.md
  - Columns: Chapter Number | Chapter Name | Script Status | Recording Status | Review Status | Upload Status
  - Pre-fill all 30 chapters (14 Maths + 16 Science) as "To Do"
- [ ] Save in `03_Content/`

### 8. Video Script — Chapter 1 (Maths)
- [ ] Ask Cowork to draft a 6-minute video script for:
  "Class 6 Maths Chapter 1: Knowing Our Numbers"
  - Tone: Friendly, relatable, Hindi/English mixed
  - Structure: Hook (30s) → Concept explanation (4 min) → Real-life example (1 min) → Quick quiz (30s)
- [ ] Save draft in `03_Content/Class6_Maths/Ch01_Script_Draft.docx`

### 9. Video Script — Chapter 1 (Science)
- [ ] Ask Cowork to draft a 6-minute video script for:
  "Class 6 Science Chapter 1: Food: Where Does It Come From?"
  - Same structure as Maths script above
- [ ] Save draft in `03_Content/Class6_Science/Ch01_Script_Draft.docx`

### 10. Practice Question Bank — Chapter 1 (Maths)
- [ ] Ask Cowork to generate 15 practice questions for Ch 1 Maths:
  - 5 Easy (direct formula/concept application)
  - 5 Medium (multi-step problems)
  - 5 Hard (HOTS — Higher Order Thinking Skills)
  - Each question: Include correct answer + explanation
- [ ] Save in `03_Content/Class6_Maths/Ch01_Questions.docx`

---

## 📋 QUICK TASKS FOR COWORK RIGHT NOW

These are short tasks you can assign to Cowork immediately:

1. **"Create the EduBharat project folder structure on my Desktop"**
2. **"Create a Word document user interview guide for Class 6-8 students based on the questions in COMPETITIVE_ANALYSIS.md"**
3. **"Create a content production tracker Excel sheet from the curriculum map"**
4. **"Draft a 6-minute video script for Class 6 Maths Chapter 1"**
5. **"Create a project timeline Gantt chart in Excel for the 4-month MVP"**
6. **"Generate a brand identity brief document for EduBharat"**

---

## 📊 Week 1 Success Metrics
- [ ] Project folder structure created on computer
- [ ] All 5 competitor screenshots saved
- [ ] 3 interview templates ready
- [ ] NCERT PDFs downloaded
- [ ] Brand brief drafted
- [ ] Content tracker spreadsheet created
