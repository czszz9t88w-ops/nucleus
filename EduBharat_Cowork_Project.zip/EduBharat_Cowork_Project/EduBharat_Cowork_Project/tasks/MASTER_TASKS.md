# ✅ EduBharat — Master Task List

> **Legend:** 🔴 Phase 1 (MVP) | 🟡 Phase 2 | 🟢 Phase 3 | ⬜ Not Started | 🔵 In Progress | ✅ Done

---

## 🔴 PHASE 1 — Foundation & MVP (Months 1–4)
### Goal: Class 6 | Maths + Science | CBSE | Core platform live

---

### 1.1 Research & Validation
- [ ] ⬜ Conduct 20 student interviews (Class 6–8, mixed Tier 1 + Tier 2 cities)
- [ ] ⬜ Conduct 10 teacher interviews (CBSE school teachers)
- [ ] ⬜ Survey 50 parents on device usage + willingness to pay
- [ ] ⬜ Map Class 6 Maths NCERT chapters (14 chapters) with learning objectives
- [ ] ⬜ Map Class 6 Science NCERT chapters (16 chapters) with learning objectives
- [ ] ⬜ Audit DIKSHA content quality for Class 6 (identify gaps)
- [ ] ⬜ Document device profile: Android version, screen size, RAM of target users
- [ ] ⬜ Define accessibility requirements (WCAG 2.1 AA checklist)

### 1.2 Product Design
- [ ] ⬜ Create user personas (Student Riya / Student Arjun / Teacher Meena / Parent Sunita)
- [ ] ⬜ Build user journey map for first-time student onboarding
- [ ] ⬜ Design sitemap (full platform information architecture)
- [ ] ⬜ Create low-fidelity wireframes: Homepage, Subject Dashboard, Chapter Map
- [ ] ⬜ Create low-fidelity wireframes: Video Player, Practice Mode, Quiz Battle
- [ ] ⬜ Create low-fidelity wireframes: Progress Dashboard, Badge Wall
- [ ] ⬜ Define gamification mechanics document (XP values, streak rules, badge criteria)
- [ ] ⬜ Define bilingual (Hindi/English) UX toggle specification
- [ ] ⬜ Create high-fidelity designs in Figma (student-facing)
- [ ] ⬜ Create high-fidelity designs: Teacher dashboard
- [ ] ⬜ Create high-fidelity designs: Parent progress report screen

### 1.3 Content Production (Class 6 — Maths + Science)
- [ ] ⬜ Script 14 × Maths Chapter Intro capsules (5–7 min each)
- [ ] ⬜ Script 16 × Science Chapter Intro capsules (5–7 min each)
- [ ] ⬜ Animate / record Maths Chapter 1–7 videos (Hindi + English)
- [ ] ⬜ Animate / record Maths Chapter 8–14 videos (Hindi + English)
- [ ] ⬜ Animate / record Science Chapter 1–8 videos (Hindi + English)
- [ ] ⬜ Animate / record Science Chapter 9–16 videos (Hindi + English)
- [ ] ⬜ Create 15 practice questions per chapter (Maths) with solutions
- [ ] ⬜ Create 15 practice questions per chapter (Science) with solutions
- [ ] ⬜ Map NCERT exercise questions with step-by-step solutions (Maths)
- [ ] ⬜ Map NCERT exercise questions with step-by-step solutions (Science)
- [ ] ⬜ Create chapter summary infographic cards (30 total: 14 Maths + 16 Science)
- [ ] ⬜ Create 3 sample papers for Class 6 Maths (CBSE pattern)
- [ ] ⬜ Create 3 sample papers for Class 6 Science (CBSE pattern)

### 1.4 Tech Development (Frontend)
- [ ] ⬜ Set up tech stack (Next.js / React + Tailwind CSS)
- [ ] ⬜ Build PWA configuration (installable, offline-ready)
- [ ] ⬜ Build authentication system (student login, parent login, teacher login)
- [ ] ⬜ Build onboarding flow (class selector → board → language preference)
- [ ] ⬜ Build subject dashboard with chapter map (visual level map)
- [ ] ⬜ Build video capsule player (controls, speed selector, CC support)
- [ ] ⬜ Build practice mode (MCQ, fill-in-blank, drag-drop question types)
- [ ] ⬜ Build quiz battle mode (1v1 vs AI, timed)
- [ ] ⬜ Build gamification layer (XP counter, streak tracker, badge unlock animations)
- [ ] ⬜ Build leaderboard (class level)
- [ ] ⬜ Build student progress dashboard (heatmap, time tracker)
- [ ] ⬜ Build parent dashboard (weekly report, weak topics)
- [ ] ⬜ Implement Hindi/English language toggle
- [ ] ⬜ Implement low-data mode (audio + slides only)
- [ ] ⬜ Implement offline download (up to 5 capsules)

### 1.5 Tech Development (Backend)
- [ ] ⬜ Set up database schema (users, progress, content, gamification)
- [ ] ⬜ Build content management system (CMS) for uploading videos + questions
- [ ] ⬜ Build adaptive difficulty engine (adjusts question hardness based on performance)
- [ ] ⬜ Build progress tracking APIs
- [ ] ⬜ Build gamification engine (XP calculation, streak logic, badge triggers)
- [ ] ⬜ Build notification system (daily streak reminder, weekly report)
- [ ] ⬜ Set up CDN for video delivery (low-latency India-region)
- [ ] ⬜ Set up analytics pipeline (student engagement metrics)

### 1.6 Pilot & Launch
- [ ] ⬜ Identify 3–5 pilot schools in Delhi NCR / Noida region
- [ ] ⬜ Run 6-week classroom pilot with 200 students
- [ ] ⬜ Collect pilot feedback (students + teachers)
- [ ] ⬜ Iterate on top 10 feedback items
- [ ] ⬜ Soft launch to 1,000 students (invite-only beta)
- [ ] ⬜ Collect NPS score and engagement metrics
- [ ] ⬜ Public launch — Class 6 MVP

---

## 🟡 PHASE 2 — Scale & Deepen (Months 5–9)
### Goal: Add Class 7 + 8, all subjects, AI Doubt Solver, state boards

- [ ] ⬜ Expand content: Class 7 — Maths, Science, SST, English, Hindi
- [ ] ⬜ Expand content: Class 8 — Maths, Science, SST, English, Hindi
- [ ] ⬜ Add Class 6 remaining subjects: SST, English, Hindi
- [ ] ⬜ Build AI Photo Doubt Solver (camera → question → AI step-by-step answer)
- [ ] ⬜ Build AI Concept Chatbot (text Q&A with subject-specific AI tutor)
- [ ] ⬜ Build Adaptive Test Generator (personalized weak-topic tests)
- [ ] ⬜ Build Virtual Lab Simulations (Science — Physics + Chemistry + Biology)
- [ ] ⬜ Build Coding Module (Scratch for Class 6, Python blocks for Class 7–8)
- [ ] ⬜ Build National Leaderboard (across all registered students)
- [ ] ⬜ Build School/Teacher Portal (assign homework, track class, generate worksheets)
- [ ] ⬜ Launch EduBharat Plus subscription (₹299/month)
- [ ] ⬜ Add Sample Papers for Class 7 and 8 (CBSE + 2 state boards)
- [ ] ⬜ Launch Olympiad Prep module (IMO, NSO)
- [ ] ⬜ Expand to UP Board and MP Board curriculum mapping

---

## 🟢 PHASE 3 — Ecosystem (Months 10–18)
### Goal: Full platform, regional languages, school B2B, career module

- [ ] ⬜ Regional language content: Marathi, Telugu, Tamil, Bengali
- [ ] ⬜ School institutional licensing model + sales pipeline
- [ ] ⬜ Career Discovery module (personality quiz + career path suggestions)
- [ ] ⬜ Life Skills & Arts modules (NEP 2020 compliant)
- [ ] ⬜ Parent community feature (moderated forum)
- [ ] ⬜ Teacher content marketplace (teachers upload + earn from content)
- [ ] ⬜ AI-powered personalised study plan generator
- [ ] ⬜ NTSE / scholarship exam prep content
- [ ] ⬜ Expand to all major state boards (Karnataka, Maharashtra, Tamil Nadu, WB)
- [ ] ⬜ Launch Android app on Play Store (native app, not just PWA)
- [ ] ⬜ Corporate CSR partnerships for free school access
- [ ] ⬜ Govt partnership exploration (DIKSHA, PM e-VIDYA integration)
