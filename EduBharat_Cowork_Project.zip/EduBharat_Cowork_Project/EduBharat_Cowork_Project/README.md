# 🎓 EduBharat — Cowork Project
## Digital Learning Platform for Class 6-8 | Indian Curriculum

---

### 📁 How This Project Is Organised

| File / Folder | What It Contains | Start Here? |
|---------------|-----------------|-------------|
| `INSTRUCTIONS.md` | AI instructions for Cowork — read this first | ✅ YES |
| `tasks/SPRINT1_NOW.md` | What to do this week — immediate action list | ✅ YES |
| `tasks/MASTER_TASKS.md` | Full Phase 1–3 task list across the project | ✅ YES |
| `research/COMPETITIVE_ANALYSIS.md` | Competitor research, market data, UX best practices | For research tasks |
| `architecture/PLATFORM_ARCHITECTURE.md` | Full sitemap, feature specs, tech stack, gamification | For product tasks |
| `architecture/BUSINESS_MODEL.md` | Pricing, revenue model, GTM strategy, funding plan | For business tasks |
| `curriculum/CLASS6_CURRICULUM_MAP.md` | Chapter-by-chapter content plan for all Class 6 subjects | For content tasks |
| `templates/COWORK_PROMPT_TEMPLATES.md` | Ready-to-use Cowork task prompts — copy and paste | ✅ YES |

---

### 🚀 Quick Start: First 3 Things to Do in Cowork

1. Create the project folder structure on your computer
2. Generate your first video script using Template 1
3. Create your content production tracker spreadsheet

---

### 🎯 North Star Goal
"Be the first Indian EdTech platform that combines Byju's content quality, Khan Academy's adaptive intelligence, DIKSHA's free access, and NEP 2020-native design for Class 6-8."

Last updated: May 2026 | Version 1.0
