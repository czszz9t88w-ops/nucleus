# PHASE 1 TASKS — EduBharat MVP Build
*Cowork: Start here. Execute tasks in order. Mark each [DONE] when complete.*
*Status: [ACTIVE] | Target: Month 1-4*

---

## 🔴 WEEK 1-2 — Foundation & Research

### Task 1.1 — Market Validation Survey [NEEDS REVIEW]
**Cowork Action:** Create a Google Form survey for student/parent validation
- Create a 10-question survey targeting Class 6-8 parents in Delhi/NCR/Noida
- Questions to include:
  - Current platforms used (if any)
  - Monthly spend on tuition/EdTech
  - Biggest pain points with existing options
  - Which features they'd pay for
  - Preferred language (Hindi/English)
  - Device used by child (phone/tablet/laptop)
- Output: `01_Research/validation_survey.md` with all questions listed

### Task 1.2 — Competitor Feature Audit
**Cowork Action:** Create a detailed feature audit spreadsheet
- Compare 6 platforms: DIKSHA, Khan Academy, Byju's, Vedantu, Magnet Brains, Meritnation
- For each platform, audit: Onboarding flow, Content quality, Gamification depth, Mobile experience, Pricing clarity
- Reference file: `01_Research/competitive_analysis.md`
- Output: `01_Research/competitor_feature_audit.xlsx`

### Task 1.3 — NCERT Syllabus Map (Class 6 Priority)
**Cowork Action:** Create a complete chapter map
- List every chapter in Class 6 Maths and Science (NCERT)
- For each chapter: Chapter name, No. of topics, No. of exercises, Key concepts, Expected video count (5-7 min each), Expected practice questions needed (min 20/chapter)
- Output: `04_Content_Structure/class6_chapter_map.md`

---

## 🔴 WEEK 3-4 — Product Definition

### Task 1.4 — User Persona Documents
**Cowork Action:** Create 4 detailed user persona files
Create separate markdown files for:
1. **Arjun (Student)** — Class 7, Delhi, studies on dad's phone, competitive, wants to top class
2. **Priya (Student)** — Class 6, Noida, shy, struggles with Maths, needs encouragement
3. **Meena (Parent)** — Mother in Ghaziabad, not tech-savvy, wants WhatsApp updates, tight budget
4. **Rajesh Sir (Teacher)** — Class 7 Science teacher, 15 years experience, skeptical of apps, wants simple tools
- For each: Background, Goals, Frustrations, How they'll use EduBharat, What will make them stay
- Output: `02_Planning/user_personas.md`

### Task 1.5 — MVP Feature Specification
**Cowork Action:** Write detailed specifications for Phase 1 features
For each feature in Phase 1 from `02_Planning/feature_roadmap.md`:
- Write: User story ("As a student, I want to...")
- Acceptance criteria (what "done" looks like)
- Edge cases to handle
- Output: `02_Planning/mvp_feature_specs.md`

### Task 1.6 — Content Production Plan
**Cowork Action:** Create a content production schedule
- Calculate total content needed for Phase 1 (Class 6 Maths + Science)
- Estimate: Total videos needed, Total practice questions needed, Total NCERT solutions needed
- Create a 4-month production calendar with weekly targets
- Identify: In-house production vs. outsource vs. curate from DIKSHA/YouTube
- Output: `04_Content_Structure/content_production_plan.md`

---

## 🔴 MONTH 2 — Design & Development Setup

### Task 1.7 — Brand Guidelines Document
**Cowork Action:** Create the brand identity specification
- Platform name options: EduBharat, PadhoBharat, ShikhoBharat (mark for Rishav to decide)
- Color palette (primary, secondary, accent — refer to `05_Design_References/brand_guidelines.md`)
- Typography choices for Hindi + English
- Logo brief (for designer handoff)
- Tone of voice: Friendly, encouraging, never condescending, celebration-focused
- Output: `05_Design_References/brand_guidelines.md` (update with full detail)

### Task 1.8 — Wireframe Specification
**Cowork Action:** Write detailed wireframe requirements for 8 key screens
Create wireframe description documents for:
1. Home screen (logged in student)
2. Subject dashboard
3. Chapter map (level/progress view)
4. Video player screen
5. Practice question screen
6. Streak/XP/Badge screen
7. Parent dashboard
8. Teacher homework assignment screen
- For each screen: Layout description, Key elements, User actions, Navigation flow, Mobile vs desktop differences
- Output: `05_Design_References/wireframe_specs.md`

### Task 1.9 — Technical Architecture Diagram
**Cowork Action:** Write out a detailed tech requirements document
- Based on `02_Planning/tech_stack.md`, create a developer-ready specification
- Include: API endpoints needed (list all), Database schema (key tables), Authentication flow, Offline sync mechanism, Video streaming setup
- Output: `02_Planning/technical_spec.md`

---

## 🔴 MONTH 3 — Content & Development

### Task 1.10 — Question Bank: Class 6 Maths
**Cowork Action:** Create structured question templates
- For each chapter in Class 6 Maths NCERT:
  - 5 Easy questions (direct formula application)
  - 5 Medium questions (2-step problems)
  - 5 Hard questions (application + reasoning)
  - 2 Real-life application questions
  - 3 NCERT exercise questions (flag source)
- Format: Question | Options (if MCQ) | Correct Answer | Explanation | Difficulty | NCERT Chapter Reference
- Output: `04_Content_Structure/q_bank_class6_maths.md`

### Task 1.11 — Question Bank: Class 6 Science
**Cowork Action:** Create structured question templates (same format as 1.10 above)
- Cover: Food (Where does it come from), Components of Food, Fibre to Fabric, Sorting Materials, Separation of Substances, Changes Around Us, Getting to Know Plants, Body Movements, Living/Non-living, Motion and Measurement, Light Shadows and Reflections, Electricity and Circuits, Fun with Magnets, Water, Air Around Us, Garbage In Garbage Out
- Output: `04_Content_Structure/q_bank_class6_science.md`

### Task 1.12 — Video Script Templates
**Cowork Action:** Create 3 sample video scripts (for outsourced production)
- Pick 3 chapters from Class 6 Maths or Science
- Write full narration scripts for 5-7 minute animated videos
- Include: Scene descriptions, On-screen text, Narration text, Animation cues, NCERT reference
- Format: Production-ready script that can be handed to a video studio
- Output: `04_Content_Structure/sample_video_scripts.md`

---

## 🔴 MONTH 4 — Testing & Launch Prep

### Task 1.13 — School Outreach Email Templates
**Cowork Action:** Create 3 email/WhatsApp message templates
1. **Cold outreach to school principal** (introducing EduBharat)
2. **Teacher recruitment message** (WhatsApp group message for teacher adoption)
3. **Parent announcement letter** (to be sent by school to parents)
- Tone: Formal (principals), Friendly (teachers), Reassuring (parents)
- Languages: English version + Hindi version for each
- Output: `03_Tasks/outreach_templates.md`

### Task 1.14 — Launch Checklist
**Cowork Action:** Create a pre-launch quality checklist
- 50+ item checklist covering: Content completeness, Tech functionality, Security checks, Performance benchmarks, User testing sign-off, Legal (privacy policy, T&Cs), Marketing materials ready, Support process in place
- Output: `03_Tasks/launch_checklist.md`

### Task 1.15 — KPI Dashboard Template
**Cowork Action:** Create a tracking spreadsheet template
- Weekly metrics to track: DAU/MAU, Session duration, Retention (D1/D7/D30), Content completion rate, Streak maintenance %, Conversion (free → paid), School onboarding count, NPS score
- Output: `03_Tasks/kpi_tracker.xlsx`

---

## ✅ Completion Criteria for Phase 1

All tasks above marked [DONE] AND:
- [ ] MVP technically functional (can register, learn, practice, track progress)
- [ ] Class 6 Maths + Science content complete (all chapters)
- [ ] 10 teachers have accessed teacher dashboard
- [ ] 100 students tested the platform (beta)
- [ ] All [NEEDS REVIEW] items reviewed by Rishav
- [ ] Privacy policy + Terms of service live
- [ ] Launch date confirmed
