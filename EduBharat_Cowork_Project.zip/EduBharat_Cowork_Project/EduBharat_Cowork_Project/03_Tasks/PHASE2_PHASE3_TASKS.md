# PHASE 2 & 3 TASKS — EduBharat Scale
*Cowork: Begin only after Phase 1 tasks complete. Reference PHASE1_TASKS.md first.*
*Status: [PENDING] | Target: Month 5-12*

---

## PHASE 2 TASKS (Month 5-8)

### Task 2.1 — Expand to Class 7 & 8 Content
- Map all Class 7 and 8 chapters (Maths, Science, SST, English, Hindi)
- Commission video production for all new chapters
- Build question bank for Class 7 and 8 (minimum 20 questions per chapter)
- Output: `04_Content_Structure/class7_chapter_map.md` + `class8_chapter_map.md`

### Task 2.2 — Premium Tier Launch
- Define all premium-only features (reference `02_Planning/business_model.md`)
- Set up payment gateway (Razorpay India — most widely used)
- Create upgrade flow (free → Plus) in-app
- Set up billing, receipts, GST-compliant invoicing
- Create cancellation and refund policy [NEEDS REVIEW]

### Task 2.3 — Quiz Battle Mode
- Design 1v1 quiz battle UX (matchmaking → countdown → 10 questions → results)
- Define rules: 30 seconds per question, same chapter/topic for both players
- Build real-time WebSocket connection for live battles
- Add post-battle XP rewards and badge triggers

### Task 2.4 — Virtual Lab Simulations
- Identify 10 Science experiments for Class 6-8 that can be simulated
- Priority: Refraction of light, Magnetic field mapping, Photosynthesis, Titration
- Source: PhET simulations (University of Colorado — free to use) as reference
- Commission or adapt HTML5-based simulations

### Task 2.5 — School Partnership Agreements
- Draft school partnership agreement template [NEEDS REVIEW — legal]
- Create school onboarding kit (PDF guide for principals, setup guide for IT, teacher quick-start guide)
- Define SLA for school tier (uptime guarantee, support response time)

### Task 2.6 — National Marketing Campaign
- Identify 5 parent Facebook/WhatsApp groups in Delhi NCR for beta promotion
- Create social media content calendar (Instagram, YouTube Shorts, Facebook)
- Produce 3 short testimonial videos (student + parent success stories from beta)
- Submit platform to NCERT/CBSE partnership inquiry (official website forms)

---

## PHASE 3 TASKS (Month 9-12)

### Task 3.1 — State Board Expansion
- Start with: UP Board (largest — 30M+ students)
- Map UP Board Class 6-8 syllabus differences from NCERT
- Create content adaptation guide for teachers who'll create state board content
- Launch: MP Board, Rajasthan Board in same quarter

### Task 3.2 — Regional Language Content
- Prioritize: Hindi (already done), Marathi, Tamil, Telugu (in that order)
- Translate all UI strings to Marathi (JSON language file)
- Commission voiceovers for top 20% most-watched videos in Marathi
- Partner with local language educators for content review

### Task 3.3 — Android Native App
- Convert PWA to React Native app
- Add native features: Camera (doubt photo), Notifications, Better offline sync
- Submit to Google Play Store (process takes 2-3 weeks for review)
- Target: Under 15MB install size

### Task 3.4 — Teacher Certification Program
- Design "EduBharat Certified Educator" program
- 5-module online course: Platform usage, digital pedagogy, analytics interpretation, student motivation, content creation
- Issue verifiable digital certificate (linked to teacher's profile)
- Price: ₹1,999/teacher OR free for teachers from partner schools

### Task 3.5 — Institutional API & ERP Integration
- Document public API for school ERP integration
- Priority integrations: Fedena (popular in Indian schools), SchoolMint, MySchoolPage
- Create developer documentation portal

### Task 3.6 — Seed/Series A Fundraising Prep
- Prepare investor pitch deck (15 slides — reference all research files in this project)
- Create financial model (5-year projections based on `02_Planning/business_model.md`)
- Compile metrics dashboard (growth, retention, revenue, NPS)
- Identify 20 target investors (angel + seed VCs focused on India EdTech)
- Output: `02_Planning/investor_pitch_deck_outline.md`
