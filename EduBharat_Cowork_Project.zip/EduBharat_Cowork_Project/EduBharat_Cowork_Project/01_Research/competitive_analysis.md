# Competitive Analysis — Indian EdTech for Class 6-8
*Status: [FINAL] | Last updated: May 2026*

---

## 1. Market Overview

- India has 260M+ K-12 students; 82% of schools now use hybrid learning models (2025)
- India EdTech sector projected to reach $313 billion by 2030
- Class 6-8 is the **most underserved segment** — majority of investment goes to Class 10/12 board prep
- 15,000+ schools use AI-powered adaptive learning platforms (2025)

---

## 2. Platform-by-Platform Analysis

### 🟢 DIKSHA (Government — diksha.gov.in)
- **Strength:** 80,000+ curriculum-linked content pieces in 15 languages; NCERT/CBSE aligned Grades 6-10; completely free; includes videos, quizzes, interactive games, lesson plans
- **Weakness:** Extremely outdated UI; zero gamification; very low student engagement; poor mobile experience
- **Our Opportunity:** Match the free model + massively improve UX and engagement

### 🟡 Khan Academy (khanacademy.org)
- **Strength:** Adaptive mastery tracking — shows different versions of problems until concept sticks; tracks exactly where a student struggles; Hindi content expanded since 2022
- **Weakness:** US-centric curriculum; limited Hindi content; no Indian board mapping; no gamification
- **Our Opportunity:** India-first adaptive engine with NCERT chapter mapping

### 🔴 Byju's (byjus.com)
- **Strength:** 50,000+ interactive videos in 6+ languages; adaptive Warm-Up/Sprint/Race modes; real-time progress reports; covers Classes 4-10 Maths, Science, SST
- **Weakness:** Very expensive (₹15,000-40,000/year); extremely aggressive sales tactics; subscription wall after 15 days; poor customer service
- **Our Opportunity:** Same content quality at accessible/free price point

### 🟡 Vedantu (vedantu.com)
- **Strength:** Live 2-teacher model; real-time doubt solving; 35M+ active users; covers Class 1-12; fastest growing K-12 platform in India
- **Weakness:** Premium pricing (₹5,000-1,00,000 per course); internet-dependent; no offline mode
- **Our Opportunity:** Free live doubt forum + offline content download

### 🟢 Magnet Brains (magnetbrains.com)
- **Strength:** 100% free; covers K-12 Hindi + English medium; NCERT/CBSE aligned; 10M+ learners; includes AI, Psychology, Entrepreneurship
- **Weakness:** Video-only (no interactivity); no gamification; no practice sets; no adaptive learning
- **Our Opportunity:** Add full gamification + interactive practice layer on top of free video content

### 🟡 Meritnation
- **Strength:** Study materials, live classes, multiple boards (CBSE, ICSE, state)
- **Weakness:** Cluttered UI; premium wall appears too early; limited free content
- **Our Opportunity:** Clean UI + generous free tier to build trust first

### 🟢 Learnohub / ExamFear
- **Strength:** Free video lessons with notes; NCERT-aligned; strong community following; doubt clearance
- **Weakness:** No gamification; no adaptive testing; basic design; video-only
- **Our Opportunity:** Full platform experience vs. video library

---

## 3. Feature Gap Matrix

| Feature | DIKSHA | Khan Academy | Byju's | Vedantu | EduBharat Target |
|---------|--------|-------------|--------|---------|-----------------|
| Free Access | ✅ | ✅ | ❌ | ❌ | ✅ Full free tier |
| NCERT-Aligned | ✅ | Partial | ✅ | ✅ | ✅ Complete |
| Hindi Medium | ✅ | Partial | ✅ | ✅ | ✅ Full bilingual |
| Gamification | ❌ | Basic | ✅ | Basic | ✅ Advanced |
| Adaptive Learning | ❌ | ✅ | ✅ | Partial | ✅ AI-powered |
| Offline Mode | ❌ | ❌ | Partial | ❌ | ✅ Full offline |
| Teacher Dashboard | ❌ | Basic | ❌ | Basic | ✅ Full portal |
| NEP 2020 Native | ❌ | ❌ | ❌ | ❌ | ✅ Born-aligned |
| Coding Module | ❌ | ❌ | ❌ | Paid | ✅ Included free |
| Virtual Labs | ❌ | ❌ | Paid | ❌ | ✅ Phase 2 |
| AI Doubt Solver | ❌ | ❌ | Paid | Partial | ✅ Free (basic) |
| State Boards | ✅ | ❌ | Partial | Partial | Phase 2 |

---

## 4. Key Competitive Insight

**No platform simultaneously offers:**
1. Byju's content quality
2. Khan Academy's adaptive intelligence
3. DIKSHA's free access
4. NEP 2020 native design
5. Teacher portal for school adoption

**EduBharat can be the FIRST to combine all five.**

---

## 5. Platforms to Study/Reference for Design

- Khan Academy's mastery/progress UI → adopt for chapter maps
- Duolingo's streak and XP system → adopt for daily engagement
- DIKSHA's content library structure → curate and improve upon
- Byju's animated video style → create NCERT-aligned equivalent
- Kahoot's quiz battle format → adapt for subject-based battles
