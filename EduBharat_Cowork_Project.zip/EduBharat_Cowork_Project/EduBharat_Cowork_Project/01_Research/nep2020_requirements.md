# NEP 2020 Requirements for EduBharat
*Status: [FINAL] | Last updated: May 2026*

---

## 1. Overview: Why NEP 2020 Compliance Is Critical

- NEP 2020 is now implemented across 67% of Indian schools (2025 data)
- Schools adopting new curriculum frameworks will actively seek NEP-aligned platforms
- Being "NEP 2020 native" vs. retrofitted = massive credibility advantage
- Government tenders and school partnerships require NEP alignment documentation

---

## 2. The 5+3+3+4 Structure — Middle Stage Focus

EduBharat targets the **Middle Stage:**
- Ages: 11-14
- Classes: 6, 7, 8
- NEP emphasis: Critical thinking, abstraction, creativity, coding, vocational exposure

---

## 3. NEP 2020 Mandates and EduBharat Response

| NEP 2020 Mandate | EduBharat Feature | Phase |
|-----------------|------------------|-------|
| Critical Thinking over rote learning | Socratic quiz mode; open-ended questions; case studies | 1 |
| Coding from Class 6 onwards | Scratch (Class 6), Python blocks (Class 7-8), Text Python (Class 8) | 1 |
| Competency-based assessment (not just marks) | Topic mastery badges; skill completion certificates | 1 |
| Multilingual education | Hindi + English full bilingual; regional languages in Phase 3 | 1 |
| Experiential/activity-based learning | Virtual lab simulations; interactive experiments | 2 |
| Vocational exposure | Career discovery module; skill videos; industry Q&A | 2 |
| Art + Life Skills integration | Health, creative arts, financial literacy, citizenship | 3 |
| Technology integration (AI/digital literacy) | AI Tutor, Digital Skills module, Coding track | 1-2 |
| Inclusive education | Accessibility features; content for diverse learners | 1 |
| Reduced exam stress | Formative assessments; no "fail" messaging; growth mindset framing | 1 |

---

## 4. Competency-Based Learning Framework

### What It Means in Practice
- Students are assessed on **what they can DO**, not just what they can memorize
- Each chapter has **Learning Outcomes** (LOs) mapped to NCERT competencies
- Mastery is shown when a student can apply a concept in a new context

### EduBharat Implementation
```
For every chapter:
→ Define 3-5 Learning Outcomes (mapped to NCERT competency codes)
→ Tag each practice question to a specific Learning Outcome
→ Student "masters" a chapter only when they clear ALL Learning Outcomes
→ Mastery badge is awarded (not just a percentage score)
```

---

## 5. NEP 2020: Coding Curriculum Requirements for Class 6-8

### Class 6 — Scratch Visual Programming
- Algorithms and sequencing
- Loops and conditionals
- Creating simple animations and stories
- Introduction to computational thinking

### Class 7 — Block-Based Python / Scratch Advanced
- Functions and modular programming
- Introduction to variables and data types
- Building interactive projects
- Introduction to problem decomposition

### Class 8 — Python Text Programming
- Basic Python syntax
- Input/output, conditionals, loops
- Functions and basic data structures (lists, dictionaries)
- Build a small project: Calculator, Quiz game, or Simple website

---

## 6. Key Digital Platforms Aligned with NEP 2020

These are government platforms EduBharat can reference, integrate with, or complement:

| Platform | Purpose | Integration Opportunity |
|---------|---------|----------------------|
| DIKSHA (diksha.gov.in) | Government content repository | Link to DIKSHA for supplementary content |
| SWAYAM | Online courses | Reference for advanced learners |
| PM e-VIDYA | DTH + digital education | Complement with interactive practice |
| NDEAR | National Digital Education Architecture | Future API integration |
| NIPUN Bharat | Foundational literacy/numeracy | Below our target grade but reference for standards |

---

## 7. Assessment Philosophy (NEP-Aligned)

### DO:
- Use formative assessments (regular low-stakes checks)
- Show growth over time (compare student to themselves, not just classmates)
- Reward effort and consistency, not just exam performance
- Provide detailed feedback on WHY an answer was wrong

### DON'T:
- Never use "FAIL" or "WRONG" messaging — use "Try Again" or "Almost There"
- Don't rank students publicly without their consent
- Don't make a single test determine a student's "level"
- Don't create anxiety around speed — offer untimed practice mode

---

## 8. Language Policy (NEP Multilingual Mandate)

### Phase 1 (Launch):
- Full content in English medium
- Full content in Hindi medium
- User selects at onboarding; can toggle anytime
- All UI elements bilingual (English + Hindi side by side or toggle)

### Phase 2:
- Marathi, Tamil, Telugu, Bengali content
- Hinglish mode (Hindi explanations + English terms for science/math)

### Phase 3:
- All 8 scheduled languages under NEP 2020
- Regional language text + Hindi/English audio

---

## 9. Data & Privacy Requirements

- Must comply with India's **DPDP Act 2023** (Digital Personal Data Protection)
- Students under 18 require parental consent for data collection
- No selling of student data to third parties
- Minimum data collection — only what's needed for learning analytics
- Parents can request full data deletion at any time
