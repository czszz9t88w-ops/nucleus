# EduBharat — Brand & UI/UX Guidelines
*Status: [DRAFT — NEEDS REVIEW] | Last updated: May 2026*

---

## 1. Brand Identity

### Platform Name Options [NEEDS RISHAV DECISION]
| Option | Meaning | Availability Check Needed |
|--------|---------|--------------------------|
| EduBharat | Education + India | edubharat.in |
| PadhoBharat | Let's Study India | padho.in |
| GyanPath | Path of Knowledge | gyanpath.in |
| ShikshaHub | Education Hub | shikshahub.in |
| Abhyaas | Practice/Study | abhyaas.in |

### Tagline Options [NEEDS RISHAV DECISION]
1. *"Padhega India, Badhega India"* (Study India, Rise India)
2. *"Seekho. Khelo. Badho."* (Learn. Play. Grow.)
3. *"Har Bacche Ka Adhikar"* (Every Child's Right)
4. *"Smart Padhai, Bright Future"* (Hindi-English mix — youth friendly)

---

## 2. Color Palette

### Primary Colors
| Name | Hex Code | Usage |
|------|----------|-------|
| Deep Blue | #1A5276 | Primary brand color, headers, buttons |
| Saffron Orange | #F39C12 | Accent, highlights, CTAs, gamification rewards |
| India Green | #1E8449 | Success states, correct answers, progress |

### Secondary Colors
| Name | Hex Code | Usage |
|------|----------|-------|
| Sky Blue | #2E86C1 | Secondary buttons, links, icons |
| Light Blue | #EBF5FB | Card backgrounds, section fills |
| Warm Gold | #FEF9EC | Achievement highlights, badge backgrounds |
| Light Green | #E9F7EF | Correct answer feedback, success cards |
| Soft Red | #FDEDEC | Error feedback (never harsh — learning is safe) |
| Charcoal | #1C2833 | Body text |
| Light Grey | #F4F6F8 | Page backgrounds, disabled states |

### Gamification Colors
| State | Color | Hex |
|-------|-------|-----|
| XP Points | Gold | #F1C40F |
| Streak Active | Flame Orange | #E67E22 |
| Streak Lost | Grey | #BDC3C7 |
| Rank #1 | Gold | #FFD700 |
| Rank #2 | Silver | #C0C0C0 |
| Rank #3 | Bronze | #CD7F32 |

---

## 3. Typography

### Primary Font: Noto Sans (Google Font — supports Devanagari for Hindi)
- **Supports:** English + Hindi + all Indian languages
- **Free for commercial use:** Yes
- **Usage:** Body text, UI elements, practice questions

| Style | Weight | Size | Usage |
|-------|--------|------|-------|
| Display | 700 Bold | 32-48px | Page titles, hero sections |
| Heading 1 | 700 Bold | 24-28px | Section headers |
| Heading 2 | 600 SemiBold | 20-22px | Card titles |
| Body | 400 Regular | 16-18px | Content, questions |
| Small | 400 Regular | 14px | Labels, captions |
| Micro | 400 Regular | 12px | Timestamps, metadata |

### Secondary Font: Baloo 2 (Google Font — playful, works great for kids)
- **Usage:** Gamification elements (scores, badges, XP numbers)
- **Free for commercial use:** Yes

---

## 4. Design Principles for Age Group 11-14

### Do:
- Use bright, energetic colors (not corporate)
- Large tap targets (minimum 44x44px for all buttons)
- Clear visual hierarchy — most important thing most visible
- Celebration animations on every completion (confetti, stars, sound)
- Progress bars always visible (shows how close to next badge/level)
- Friendly illustrations (diverse Indian students — not stock photos)
- Error messages that encourage ("Almost! Try again →")

### Don't:
- Don't use red X marks for wrong answers — use "Try Again"
- Don't show percentage scores prominently — show mastery progress instead
- Don't use small text on mobile — minimum 16px body text
- Don't create dead ends — always show "What's Next"
- Don't use competitive language that shames — always encourage
- Don't add too many notifications/alerts — respect student focus time

---

## 5. Key Screen Layouts

### Home Screen (Student)
```
┌─────────────────────────────────┐
│ 🔥 Streak: 7 days  ⭐ 1,240 XP  │  (sticky top bar)
├─────────────────────────────────┤
│   Good Morning, Arjun! 👋        │
│   Continue where you left off → │
│   [Maths — Chapter 7: Fractions] │
├─────────────────────────────────┤
│   📚 Your Subjects              │
│   [Maths] [Science] [SST]       │
│   [English] [Hindi] [Coding]    │
├─────────────────────────────────┤
│   🏆 Leaderboard Snapshot       │
│   You're #3 in your class!      │
├─────────────────────────────────┤
│   📅 Today's Challenge          │
│   [Take Quick Quiz — 5 min]     │
└─────────────────────────────────┘
```

### Chapter Map (Level Map View)
```
┌─────────────────────────────────┐
│  Class 6 Maths                  │
│  ████████░░░░ 8/14 chapters     │
│                                 │
│  ✅ Ch1  ✅ Ch2  ✅ Ch3          │
│         |                       │
│  ✅ Ch4  ✅ Ch5                 │
│         |                       │
│  ✅ Ch6  ✅ Ch7                 │
│         |                       │
│  🔓 Ch8 (CURRENT) ──────────── │
│         |                       │
│  🔒 Ch9  🔒 Ch10  🔒 Ch11       │
│         |                       │
│  🔒 Ch12  🔒 Ch13  🔒 Ch14      │
└─────────────────────────────────┘
```

### Practice Question Screen
```
┌─────────────────────────────────┐
│  Chapter 7: Fractions  Q 3/10  │
│  ████████░░░░░░░░  [Timer: 45s] │
├─────────────────────────────────┤
│                                 │
│  What is 3/4 + 1/8 ?           │
│                                 │
│  A  7/8          B  4/12       │
│  C  1/2          D  5/8        │
│                                 │
├─────────────────────────────────┤
│  💡 Need a hint?               │
└─────────────────────────────────┘
```

---

## 6. Illustration Style

- **Style:** Flat 2D vector illustrations (not 3D, not photorealistic)
- **Characters:** Diverse Indian students (various skin tones, North/South/East Indian looks)
- **Setting:** Mix of urban (Delhi, Noida) and semi-urban environments
- **Expression:** Always positive, curious, celebrating small wins
- **Avoid:** Western stock photo style, stereotypical costumes, only urban elite setting
- **Reference styles:** Similar to Byju's mascot energy, but more inclusive and less branded

---

## 7. Motion & Animation

### Gamification Animations (Phase 1)
- **Correct answer:** Green burst + checkmark + "+10 XP" floating upward (0.5 sec)
- **Wrong answer:** Gentle shake + "Try Again" + hint option (no buzzer sound)
- **Chapter complete:** Confetti shower + badge unlock animation (2 sec)
- **Streak maintained:** Flame icon grows + bounce animation (1 sec)
- **Level up:** Full-screen celebration with XP total + rank update (3 sec)

### Performance Requirements
- All animations must be CSS/SVG-based (not GIF — too heavy)
- Animation files must be under 50KB each
- Must respect `prefers-reduced-motion` browser setting (accessibility)
- No autoplay audio — all sounds are off by default, student opts in
