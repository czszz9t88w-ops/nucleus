# 📄 EduBharat — Cowork Task Templates

> Copy-paste these prompts directly into Cowork to generate project documents instantly.

---

## TEMPLATE 1: Video Script Generator
```
Generate a 6-minute educational video script for EduBharat.

Details:
- Class: 6
- Subject: [SUBJECT]
- Chapter: [CHAPTER NUMBER] — [CHAPTER NAME]
- Audience: 11-12 year old Indian students
- Language style: Mix of Hindi and English (Hinglish) — friendly, warm, like an older sibling teaching
- Tone: Enthusiastic, encouraging, never condescending

Structure:
1. HOOK (0:00–0:30): A surprising fact, question, or real-life connection to grab attention
2. CONNECT TO LIFE (0:30–1:00): Relate the topic to something students see in daily life in India
3. CORE CONCEPT (1:00–4:30): Explain the main concept step by step with visual cues noted in [brackets]
4. NCERT EXAMPLE (4:30–5:30): Walk through 1 NCERT textbook example
5. QUICK RECAP (5:30–6:00): Summarise 3 key points in 3 bullets. End with: "Try the practice questions now — see you in the next chapter!"

Format: Write as a proper script with NARRATOR: and [VISUAL DESCRIPTION] tags.
Save as: [SUBJECT]_Ch[NUMBER]_Script.docx
```

---

## TEMPLATE 2: Practice Question Bank Generator
```
Generate a practice question bank for EduBharat.

Chapter: Class 6 [SUBJECT] Chapter [NUMBER] — [CHAPTER NAME]
Total questions: 15

Breakdown:
- 5 EASY questions: Direct fact recall or single-step application. MCQ format with 4 options.
- 5 MEDIUM questions: 2-3 step problem solving. MCQ or short answer.
- 5 HARD (HOTS) questions: Application, analysis, or real-world scenario. Can be descriptive.

For each question include:
- Question text
- Options (if MCQ: A, B, C, D)
- Correct answer
- 2-line explanation of WHY that's the answer
- NCERT reference (textbook page or exercise number if applicable)
- Difficulty tag: [Easy] / [Medium] / [Hard]

Format: Numbered list, clean formatting. Save as Word document.
```

---

## TEMPLATE 3: Chapter Summary Card Brief
```
Create a content brief for a Chapter Summary Infographic Card.

Chapter: Class 6 [SUBJECT] Chapter [NUMBER] — [CHAPTER NAME]

Design brief for Canva:
- Size: A4 portrait
- Colors: Primary #1A5F8A (teal-blue), Accent #F5A623 (amber), Background white
- Font: Poppins or Nunito (clean, modern, student-friendly)
- Language: Bilingual (English main, Hindi subtitle for each section)

Content to include:
1. Chapter title (large, prominent)
2. KEY CONCEPTS (3-5 bullet points with icons)
3. IMPORTANT FORMULAS/DATES/DEFINITIONS (box highlight)
4. COMMON MISTAKES TO AVOID (red-bordered box)
5. REMEMBER section (quick revision 3 points)
6. Did You Know? (interesting fact related to topic)

Tone: Fun, visual, scannable in under 2 minutes.
Output: Word document with the text content only (designer will create the visual in Canva).
```

---

## TEMPLATE 4: User Interview Report Generator
```
I have completed [NUMBER] student interviews for EduBharat.
Here are my raw notes: [PASTE INTERVIEW NOTES]

Please analyse these notes and create a structured research report with:

1. PARTICIPANT OVERVIEW (table: Name/initials, Class, City, Device used, Platform used)
2. KEY FINDINGS (top 5 insights from across all interviews)
3. PAIN POINTS (what students find difficult or frustrating about current studying)
4. DEVICE & CONNECTIVITY PROFILE (what devices, internet quality)
5. LANGUAGE PREFERENCE (Hindi vs English preference breakdown)
6. WILLINGNESS TO PAY (summary of what students/parents said about pricing)
7. FEATURE WISHLIST (what features students said they'd want in an ideal platform)
8. DIRECT QUOTES (5 best quotes to use in marketing/pitch deck)
9. RECOMMENDATIONS FOR EDUBHARAT DESIGN (3 specific design decisions based on this research)

Format as a clean Word document. Save in 01_Research/User Interviews/Research_Report.docx
```

---

## TEMPLATE 5: Weekly Progress Report
```
Generate EduBharat Weekly Project Report for Week [NUMBER].

Sections to cover:
1. WEEK SUMMARY: What was accomplished this week (check SPRINT1_NOW.md for completed tasks)
2. TASKS COMPLETED: List with dates
3. TASKS IN PROGRESS: Current status
4. BLOCKERS: Any issues or dependencies holding up work
5. NEXT WEEK PLAN: Top 5 priorities for next week
6. KEY DECISIONS MADE: Any decisions made this week that affect the project
7. OPEN QUESTIONS: Questions that need answers to proceed

Tone: Concise, factual, no fluff. 1 page max.
Save as: 06_Business/WeeklyReports/Week[NUMBER]_Report.docx
```

---

## TEMPLATE 6: Pitch Deck Outline Generator
```
Create a pitch deck outline for EduBharat for a seed investor meeting.

12 slides covering:
1. COVER: EduBharat — India's Free, NEP-Native Learning Platform for Class 6-8
2. THE PROBLEM: What's broken in Indian middle-school education today
3. THE MARKET: Size, growth, underserved Class 6-8 segment data
4. THE SOLUTION: EduBharat — what it is and how it works
5. PRODUCT: Key features (3 screenshots/wireframe descriptions)
6. CURRICULUM: NCERT/CBSE alignment, NEP 2020 compliance
7. TRACTION: Pilot results, user numbers, NPS (to be filled after pilot)
8. BUSINESS MODEL: Free vs Plus vs School licensing
9. GO-TO-MARKET: D2C → School B2B → Government partnerships
10. COMPETITION: Why EduBharat wins (feature comparison matrix)
11. FINANCIALS: Year 1 projections, funding ask, use of funds
12. TEAM: Founders and advisors

Output: Slide-by-slide content brief (text + data points for each slide).
This will be used to build the presentation in Gamma or PowerPoint.
```

---

## TEMPLATE 7: School Partnership Email
```
Write a cold email to the principal of [SCHOOL NAME] to introduce EduBharat and propose a pilot.

Context:
- EduBharat is a free digital learning platform for Class 6-8 students
- NCERT/CBSE aligned, NEP 2020 compliant
- We are offering 3-month free pilot to selected schools in [CITY]
- Includes: Teacher dashboard, student analytics, content for all Class 6-8 subjects

Email requirements:
- Subject line: 3 options to A/B test
- Length: Short (under 200 words) — principals are busy
- Tone: Respectful, confident, value-focused
- Include: A clear single call-to-action (schedule a 20-minute demo call)
- No jargon, no buzzwords
- Sign off: From EduBharat Team

Output: Email body + 3 subject line options. Save as Marketing/School_Outreach_Email.docx
```
