# EduBharat — Full Implementation Plan
## With Free APIs, Connectors & Service Stack

> Version 1.0 | May 2026 | Phase 1–3 Implementation Roadmap

---

## Part 1: Complete Free-Tier API & Service Stack

### Legend
- ✅ Truly free (no credit card, no time limit)
- ⚡ Free with CC on file (no charges until limit exceeded)
- 🕐 Free trial only (time-limited)
- 💰 Near-free (small prepaid top-up required)

---

### 1.1 Authentication & OTP

| Service | Free Tier | CC? | India Latency | Notes |
|---|---|---|---|---|
| **Firebase Auth** ✅ | 50,000 MAU/month | No | 50–80ms | Free for email/Google SSO — use for social login |
| **Fast2SMS** 💰 | ₹20–50 signup credits (~200 SMS) | No | Excellent | India-native, DLT-compliant, ₹0.12/OTP after credits |
| **MSG91** 💰 | Pay-as-you-go from ₹0.18/OTP | No | Excellent | Best for DLT compliance + enterprise reliability |
| **2Factor.in** ✅ | Free DLT OTP tier for testing | No | Good | Use for dev/staging |

**Decision for EduBharat:**
- Social/Email login → **Firebase Auth** (free forever)
- Phone OTP → **Fast2SMS** (₹100 prepaid covers ~800 OTPs for MVP)
- Production scale → **MSG91** (DLT-compliant, reliable, ₹0.18/OTP)

---

### 1.2 Video Hosting & CDN

| Service | Free Tier | CC? | India | Notes |
|---|---|---|---|---|
| **Mux Video** ✅ | 10 videos + 100K delivery min/month | No | CDN global | Best free managed video at MVP |
| **YouTube (unlisted)** ✅ | Unlimited | No | Excellent | Use for bootstrap phase; no branding control |
| **Bunny Stream** 🕐 | $20 credit trial | No | India PoPs | $0.005/min stored + $0.01/GB bandwidth |
| **Cloudflare Stream** ⚡ | 100 min stored on Workers Paid plan | Yes | Good | Not recommended for free tier |

**Decision for EduBharat:**
- Phase 1 (0–10K users): **Mux free plan** — 10 videos, 100K delivery minutes = ~1,667 hours of viewing
- Phase 1 overflow + low priority videos: **YouTube unlisted embeds** (free, highest India CDN quality via Google)
- Phase 2+ (paid tier): **Bunny Stream** (~$0.01/GB bandwidth — cheapest for India)

---

### 1.3 AI / LLM APIs

| Service | Free Tier | CC? | India | Notes |
|---|---|---|---|---|
| **Google Gemini 2.5 Flash** ✅ | 1,000 req/day, 15 RPM, 250K tokens/min | No | Global API | Best free LLM for production use |
| **Groq (Llama 3.3 70B)** ✅ | ~14,400 req/day | No | Global API | Fastest inference; great for quick Q&A |
| **Anthropic Claude API** ❌ | No free API tier | Yes | Global | Requires billing account |
| **OpenAI GPT-4o** ❌ | No free tier | Yes | Global | $2.50/1M tokens |
| **Sarvam AI** ✅ | ₹100–₹1,000 signup credits | No | India-based | Hindi/regional STT + TTS; startup program: 6–12 months free |

**Decision for EduBharat:**
- "Explain It To Me" tutor chatbot → **Gemini 2.5 Flash** (1,000 req/day free, no CC)
- Fast quiz hint generation → **Groq Llama 3.3** (speed-critical, free)
- Hindi/regional voice AI → **Sarvam AI** (signup credits + startup program)

---

### 1.4 Vernacular AI (India-Specific — Major Differentiator)

| Service | Free Tier | CC? | Notes |
|---|---|---|---|
| **Bhashini API** ✅ | Free for PoC/development; 22 Indian languages | No | Govt. of India platform; register at bhashini.gov.in |
| **Sarvam AI** ✅ | Signup credits; startup program (6–12 months) | No | 10 Indian languages, STT + TTS + translation |
| **IndicTrans2 (AI4Bharat)** ✅ | Completely free; open-source, MIT license | No | Self-hosted on HuggingFace or your server |
| **Cloudflare Workers AI (IndicTrans2)** ✅ | 10,000 neurons/day free | No | IndicTrans2 model available on Workers AI |

**Decision for EduBharat:**
- Content translation (English → Hindi curriculum text) → **Bhashini API** (govt. free, 22 languages)
- Hindi TTS (text-to-speech for voice layer) → **Sarvam AI** (best quality for Hindi)
- Offline/self-hosted translation → **IndicTrans2 via HuggingFace** (free forever)
- Edge translation (no server needed) → **Cloudflare Workers AI IndicTrans2** (10K req/day free)

---

### 1.5 Push Notifications

| Service | Free Tier | CC? | Notes |
|---|---|---|---|
| **Firebase Cloud Messaging (FCM)** ✅ | Unlimited messages, unlimited devices | No | Best option — truly unlimited and free |
| **OneSignal** ✅ | Unlimited mobile push; 10K recipients/send (web) | No | Good dashboard; use if FCM direct integration is complex |

**Decision for EduBharat:** **FCM** — unlimited, free forever, integrates with Firebase Auth, excellent India infrastructure.

---

### 1.6 Database & Backend Hosting

| Service | Free Tier | CC? | India Region | Notes |
|---|---|---|---|---|
| **Neon (PostgreSQL)** ✅ | 0.5 GB storage, 100 CU-hrs/month, no sleep penalty | No | US only (India coming) | Best free PostgreSQL — no cold starts |
| **Supabase** ✅ | 500 MB DB, 1 GB storage, 5 GB egress | No | Singapore (closest to India) | Pauses after 1 week inactivity on free |
| **Vercel (Next.js)** ✅ | 100 GB bandwidth/month, Edge PoPs in India | No | Yes (edge) | Personal/non-commercial only on Hobby |
| **Cloudflare Pages** ✅ | Unlimited bandwidth, unlimited builds, commercial OK | No | Yes (India PoPs) | Better than Vercel for commercial use (free) |
| **Render** ✅ | 512 MB RAM, 750 hrs/month, sleeps after 15 min | No | No India region | OK for API server; cold starts are a problem |

**Decision for EduBharat:**
- Next.js Frontend → **Cloudflare Pages** (unlimited bandwidth, commercial use allowed, India edge PoPs)
- PostgreSQL → **Neon free tier** (no sleep, 0.5 GB covers MVP user data)
- Node.js API → **Render** (free for MVP; upgrade to Railway/Fly.io when cold starts hurt)
- Redis (sessions, leaderboard cache) → **Upstash Redis** (free: 10,000 commands/day)

---

### 1.7 Email & WhatsApp

| Service | Free Tier | CC? | Notes |
|---|---|---|---|
| **Resend** ✅ | 3,000 emails/month (100/day cap) | No | Best developer DX; Next.js SDK available |
| **Brevo (SendinBlue)** ✅ | 300 emails/day (~9,000/month), unlimited contacts | No | Good deliverability; India-accessible |
| **WhatsApp Business API (Meta)** ✅ | User-initiated conversations: FREE (unlimited since Nov 2024) | No | Register at Meta for Developers |
| **Interakt** ✅ | 14-day free trial (Indian BSP for WhatsApp) | No | India-based WA partner; cheaper than Twilio |
| **Wati** ✅ | 7-day free trial | No | India-based WA partner |

**Decision for EduBharat:**
- Transactional email (OTP fallback, welcome) → **Resend** (clean API, Next.js SDK)
- Bulk parent communication → **Brevo** (9,000/month free covers up to ~300 parents/day)
- Parent weekly report (WhatsApp) → **Meta WhatsApp Business API direct** + **Interakt** as Indian BSP

---

### 1.8 Analytics

| Service | Free Tier | CC? | Notes |
|---|---|---|---|
| **PostHog** ✅ | 1,000,000 events/month + 5,000 session recordings | No | Feature flags + A/B testing + funnels + recordings — all in one |
| **Mixpanel** ✅ | 20,000,000 events/month | No | Better for large event volume; fewer features than PostHog |

**Decision for EduBharat:** **PostHog** — 1M events/month covers 10K DAU at 100 events/student/day. Session recordings are invaluable for understanding how 11–14-year-olds actually use the app.

---

### 1.9 OCR / Math Recognition

| Service | Free Tier | CC? | Notes |
|---|---|---|---|
| **Pix2Text (open source)** ✅ | Unlimited, self-hosted | No | Direct Mathpix alternative; LaTeX output; MIT license |
| **Google Cloud Vision** ✅ | 1,000 units/month (then $1.50/1K) | No (GCP billing needed) | General OCR; weak on math notation |
| **Mathpix API** 🕐 | $29 test credit (one-time) | Yes | Best math OCR quality; expensive at scale |

**Decision for EduBharat:**
- Phase 1 → **Google Vision API** (1,000 free requests/month, good for general text)
- Phase 2 (camera doubt solver) → **Pix2Text self-hosted** (free, handles handwritten math, deploy as microservice)

---

### 1.10 Search

| Service | Free Tier | CC? | Notes |
|---|---|---|---|
| **Meilisearch (self-hosted)** ✅ | Unlimited, open-source, MIT license | No | Fast, typo-tolerant; 512 MB RAM sufficient |
| **Algolia** ✅ | 10,000 searches/month, 1M records, 10 indices | No | Managed; deleted after 60 days inactivity |
| **Typesense (self-hosted)** ✅ | Unlimited, open-source, Apache 2.0 | No | Meilisearch alternative |

**Decision for EduBharat:** **Self-hosted Meilisearch** — free forever, runs on 512 MB RAM, deploy alongside Node.js API on Render.

---

### 1.11 Error Tracking & Monitoring

| Service | Free Tier | CC? | Notes |
|---|---|---|---|
| **Sentry** ✅ | 5,000 errors/month, 10K perf. transactions | No | Industry standard; 30-day retention |
| **GlitchTip** ✅ | Unlimited, self-hosted, Sentry-compatible | No | Best if self-hosting; Sentry-compatible SDK |

**Decision for EduBharat:** **Sentry free tier** for MVP (5K errors/month is fine for <1K DAU).

---

### 1.12 File Storage (Assets, PDFs, Thumbnails)

| Service | Free Tier | CC? | India | Notes |
|---|---|---|---|---|
| **Cloudflare R2** ⚡ | 10 GB/month, zero egress fees | Yes (CC needed) | Global edge | Best option — zero egress = no surprise bills |
| **Supabase Storage** ✅ | 1 GB, 5 GB egress | No | Singapore | Tied to Supabase project |
| **AWS S3** ⚡ | 5 GB + 100 GB transfer (12 months only) | Yes | Mumbai region | 12-month limit; not permanent |

**Decision for EduBharat:** **Cloudflare R2** — 10 GB free, zero egress fees. Critical for India where serving PDF worksheets and thumbnails to 10K students would generate significant S3 egress costs.

---

## Part 2: Implementation Plan — Phase by Phase

---

## PHASE 1: Foundation & MVP (Month 1–3)

**Goal:** 10,000 registered users, 2,000 DAU, 25% 7-day streak retention
**Team:** 2–3 developers + 1 content producer + 1 designer (optional)
**Budget:** ~₹10,000–15,000/month (prepaid APIs + domain + email)

---

### Sprint 1 (Week 1–2): Project Scaffold & Infrastructure

#### Step 1: Repository & Project Setup
```
Technology:
- Next.js 14 (App Router) with TypeScript
- Tailwind CSS + shadcn/ui component library
- Zustand (state management)
- Prisma ORM

Commands:
  npx create-next-app@latest edubharat --typescript --tailwind --app
  npm install @prisma/client prisma zustand
  npm install next-pwa workbox-webpack-plugin
```

#### Step 2: Database Setup (Neon PostgreSQL — Free)
```
1. Sign up at neon.tech (no CC required)
2. Create project "edubharat-prod"
3. Copy connection string to .env.local
4. Run: npx prisma init
5. Define schema (see Schema section below)
6. Run: npx prisma db push

Free tier: 0.5 GB storage, 100 CU-hours/month
Connection string format: postgresql://user:pass@ep-xxx.us-east-2.aws.neon.tech/edubharat
```

#### Step 3: Prisma Schema (Core Models)
```prisma
model User {
  id          String   @id @default(cuid())
  phone       String?  @unique
  email       String?  @unique
  name        String
  class       Int      // 6, 7, or 8
  board       String   // CBSE, ICSE, State
  language    String   @default("hi") // hi or en
  role        Role     @default(STUDENT)
  createdAt   DateTime @default(now())
  streak      Streak?
  progress    Progress[]
  sessions    Session[]
}

model Streak {
  id          String   @id @default(cuid())
  userId      String   @unique
  user        User     @relation(fields: [userId], references: [id])
  currentDays Int      @default(0)
  longestDays Int      @default(0)
  lastActive  DateTime @default(now())
  shields     Int      @default(0) // max 2
}

model Content {
  id          String   @id @default(cuid())
  title       String
  titleHi     String   // Hindi title
  subject     String   // maths, science, sst, hindi, english, coding
  class       Int
  chapter     Int
  topic       Int
  type        ContentType // VIDEO, QUIZ, SUMMARY, PRACTICE
  videoUrl    String?  // Mux playback URL
  durationSec Int?
  xpReward    Int      @default(10)
  progress    Progress[]
}

model Progress {
  id          String   @id @default(cuid())
  userId      String
  user        User     @relation(fields: [userId], references: [id])
  contentId   String
  content     Content  @relation(fields: [contentId], references: [id])
  completed   Boolean  @default(false)
  score       Int?     // quiz score 0-100
  xpEarned    Int      @default(0)
  hintsUsed   Int      @default(0)
  completedAt DateTime?
  nextReview  DateTime? // spaced repetition
}

model PlacementResult {
  id          String   @id @default(cuid())
  userId      String
  subject     String
  placedLevel Int      // grade level placed at (4-8)
  score       Float
  createdAt   DateTime @default(now())
}

enum Role { STUDENT PARENT TEACHER ADMIN }
enum ContentType { VIDEO QUIZ SUMMARY PRACTICE }
```

#### Step 4: Frontend Hosting (Cloudflare Pages — Free, Commercial OK)
```
1. Push code to GitHub
2. Go to dash.cloudflare.com → Pages → Create project → Connect GitHub
3. Build command: npm run build
4. Output directory: .next
5. Environment variables: add DATABASE_URL, etc.

Free: Unlimited bandwidth, unlimited builds, India PoPs, commercial use allowed
Custom domain: free (add your own domain)
```

#### Step 5: PWA + Offline Setup
```javascript
// next.config.js
const withPWA = require('next-pwa')({
  dest: 'public',
  disable: process.env.NODE_ENV === 'development',
  runtimeCaching: [
    {
      urlPattern: /^https:\/\/stream\.mux\.com\/.*/i,
      handler: 'CacheFirst',
      options: {
        cacheName: 'video-cache',
        expiration: { maxEntries: 10, maxAgeSeconds: 7 * 24 * 60 * 60 }
      }
    },
    {
      urlPattern: /\/api\/content\/.*/i,
      handler: 'StaleWhileRevalidate',
      options: { cacheName: 'content-cache' }
    }
  ]
})

// Service Worker caches:
// - Last 10 visited lesson pages
// - Quiz question sets for downloaded chapters
// - Student's XP/streak state (syncs on reconnect)
```

---

### Sprint 2 (Week 3–4): Authentication Flow

#### Firebase Auth Setup (Free — 50K MAU/month)
```javascript
// 1. Create Firebase project at console.firebase.google.com
// 2. Enable Authentication → Google + Phone providers
// 3. Install: npm install firebase

// lib/firebase.ts
import { initializeApp } from 'firebase/app'
import { getAuth } from 'firebase/auth'

const app = initializeApp({
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
})

export const auth = getAuth(app)
```

#### Phone OTP via Fast2SMS (Near-free — ₹100 prepaid)
```javascript
// API Route: /api/auth/send-otp
// Fast2SMS API — ₹0.12 per OTP

async function sendOTP(phone: string, otp: string) {
  const response = await fetch(
    `https://www.fast2sms.com/dev/bulkV2?authorization=${process.env.FAST2SMS_API_KEY}` +
    `&variables_values=${otp}&route=otp&numbers=${phone}`,
    { method: 'GET' }
  )
  return response.json()
}

// Register at fast2sms.com → Get API key → Add ₹100 wallet
// Sign up for DLT template approval (required for OTP in India)
```

#### Onboarding Flow (5 Steps)
```
Screen 1: Phone number entry → OTP verification (Fast2SMS)
Screen 2: Name + Class selection (6/7/8) + Board (CBSE/ICSE/State)
Screen 3: Language preference (Hindi / English)
Screen 4: Placement Quiz (10 questions, 5 min)
Screen 5: "Your first lesson is ready!" → Start streak
```

---

### Sprint 3 (Week 5–6): Content Player & Microlearning

#### Mux Video Integration (Free — 10 videos, 100K delivery min/month)
```javascript
// 1. Sign up at mux.com (no CC required)
// 2. Create environment → Get MUX_TOKEN_ID + MUX_TOKEN_SECRET
// 3. Install: npm install @mux/mux-player-react @mux/mux-node

// Upload video to Mux:
import Mux from '@mux/mux-node'
const mux = new Mux(process.env.MUX_TOKEN_ID, process.env.MUX_TOKEN_SECRET)

const upload = await mux.video.uploads.create({
  cors_origin: 'https://edubharat.com',
  new_asset_settings: { playback_policy: ['public'] }
})

// In component:
import MuxPlayer from '@mux/mux-player-react'

<MuxPlayer
  playbackId={content.muxPlaybackId}
  streamType="on-demand"
  defaultTextTrack="hi" // Hindi CC default
  accentColor="#4F46E5"
/>
```

#### Chapter Learning Flow (5 Steps)
```
Step 1: Concept Video (5–7 min, Mux player, bilingual CC)
Step 2: Quick Check (3 MCQs — instant XP feedback)
Step 3: Practice Set (10–15 questions — adaptive difficulty via rules)
Step 4: NCERT Solutions reference (text/PDF)
Step 5: Summary Card (downloadable PDF, bilingual)
```

---

### Sprint 4 (Week 7–8): Gamification Engine

#### Streak System
```typescript
// lib/streak.ts
export async function updateStreak(userId: string) {
  const streak = await prisma.streak.findUnique({ where: { userId } })
  const today = new Date()
  const lastActive = streak?.lastActive

  const daysSinceActive = lastActive
    ? Math.floor((today.getTime() - lastActive.getTime()) / 86400000)
    : null

  if (daysSinceActive === 0) return streak // already counted today

  if (daysSinceActive === 1) {
    // Consecutive day — increase streak
    return prisma.streak.update({
      where: { userId },
      data: {
        currentDays: { increment: 1 },
        longestDays: { increment: streak!.currentDays + 1 > streak!.longestDays ? 1 : 0 },
        lastActive: today
      }
    })
  }

  if (daysSinceActive === 2 && streak!.shields > 0) {
    // Missed 1 day — use shield (burnout guard)
    return prisma.streak.update({
      where: { userId },
      data: { shields: { decrement: 1 }, lastActive: today }
    })
  }

  // Streak broken
  return prisma.streak.update({
    where: { userId },
    data: { currentDays: 1, lastActive: today }
  })
}
```

#### XP + Level System
```typescript
const XP_REWARDS = {
  VIDEO_COMPLETE: 10,
  QUICK_CHECK_PERFECT: 15,
  PRACTICE_SET_COMPLETE: 20,
  CHAPTER_COMPLETE: 50,
  STREAK_7_DAY: 100,
  QUIZ_WIN_AI: 25,
  QUIZ_WIN_FRIEND: 40,
}

const LEVELS = [
  { name: 'Pathshala Shishya', min: 0, max: 100 },
  { name: 'Jigyasu', min: 100, max: 250 },
  { name: 'Vidyarthi', min: 250, max: 500 },
  { name: 'Prabuddha', min: 500, max: 1000 },
  { name: 'Gyaani', min: 1000, max: 2000 },
  { name: 'Medhavi', min: 2000, max: 4000 },
  { name: 'Scholar', min: 4000, max: 8000 },
  { name: 'Acharya', min: 8000, max: 15000 },
  { name: 'Vishvavidyalay Samrat', min: 15000, max: Infinity },
]
```

---

### Sprint 5 (Week 9–10): Push Notifications (FCM — Free, Unlimited)

```javascript
// 1. Add Firebase to project (already done for Auth)
// 2. Enable Cloud Messaging in Firebase console
// 3. Add VAPID key for web push

// lib/notifications.ts
import { getMessaging, getToken, onMessage } from 'firebase/messaging'

export async function requestNotificationPermission() {
  const messaging = getMessaging()
  const token = await getToken(messaging, {
    vapidKey: process.env.NEXT_PUBLIC_FIREBASE_VAPID_KEY
  })
  // Save token to DB for this user
  await fetch('/api/notifications/register', {
    method: 'POST',
    body: JSON.stringify({ fcmToken: token })
  })
}

// Server-side: send streak reminder
// /api/cron/streak-reminder — runs daily via Vercel Cron (free)
import { getMessaging } from 'firebase-admin/messaging'

const streakAtRiskUsers = await prisma.streak.findMany({
  where: {
    currentDays: { gt: 0 },
    lastActive: { lt: new Date(Date.now() - 20 * 60 * 60 * 1000) } // no activity in 20 hrs
  },
  include: { user: true }
})

for (const streak of streakAtRiskUsers) {
  await getMessaging().send({
    token: streak.user.fcmToken,
    notification: {
      title: `🔥 ${streak.currentDays} दिन की streak खतरे में!`,
      body: 'आज का एक lesson पूरा करो — streak बचाओ!'
    }
  })
}
```

---

### Sprint 6 (Week 11–12): Analytics + Error Tracking

#### PostHog Setup (Free — 1M events/month)
```javascript
// 1. Sign up at posthog.com (no CC)
// 2. npm install posthog-js

// app/layout.tsx
import posthog from 'posthog-js'
import { PostHogProvider } from 'posthog-js/react'

posthog.init(process.env.NEXT_PUBLIC_POSTHOG_KEY, {
  api_host: 'https://app.posthog.com',
  capture_pageview: false // manual control
})

// Track key events:
posthog.capture('video_completed', { subject: 'maths', chapter: 1, durationSec: 380 })
posthog.capture('streak_updated', { newStreak: 7, shieldUsed: false })
posthog.capture('placement_quiz_completed', { level: 6, subject: 'maths', score: 0.72 })
posthog.capture('lesson_started', { class: 6, subject: 'science', chapter: 3 })
```

#### Sentry Setup (Free — 5,000 errors/month)
```javascript
// npm install @sentry/nextjs
// npx @sentry/wizard@latest -i nextjs

// Automatic error capture for:
// - API route crashes
// - Client-side React errors
// - Performance monitoring
```

---

## PHASE 2: Growth & Retention (Month 4–8)

**Goal:** 50,000 users, 30% DAU/MAU, 10% free→Plus conversion, 10 school partnerships
**New monthly budget:** ~₹25,000–40,000 (Mux/Bunny, Sarvam AI, WhatsApp BSP)

---

### Feature Set: Parent Dashboard + WhatsApp Reports

#### WhatsApp Weekly Reports (Meta API — Free for user-initiated)
```javascript
// 1. Create Meta Business account → WhatsApp Business Platform
// 2. Use Indian BSP: Interakt (interakt.shop) or Wati (wati.io)
//    Both have 14-day free trials; then ~$15–50/month for small usage
// 3. Create approved message template for weekly report

// Weekly report message template (approved by Meta):
const reportTemplate = `
Hi {{parent_name}}! 🎓 EduBharat Weekly Report for {{child_name}}

📅 This Week:
✅ Lessons completed: {{lessons_count}}
🔥 Current streak: {{streak_days}} days
📊 Average score: {{avg_score}}%
📈 XP earned: {{xp_earned}}

Strong subject: {{best_subject}}
Needs attention: {{weak_subject}}

View full report: {{dashboard_link}}
`

// Schedule via Vercel Cron (free) — runs every Sunday 6 PM
// /api/cron/weekly-report
```

---

### Feature Set: Spaced Repetition Review Queue

```typescript
// FSRS (Free Spaced Repetition Scheduler) — open source
// npm install ts-fsrs

import { createEmptyCard, fsrs, generatorParameters, Rating } from 'ts-fsrs'

// After each quiz answer:
const f = fsrs(generatorParameters({ maximum_interval: 180 }))
const card = createEmptyCard()
const result = f.repeat(card, new Date())

// Based on performance:
const scheduledDate =
  score >= 80 ? result[Rating.Good].card.due    // review in ~4 days
  : score >= 60 ? result[Rating.Hard].card.due   // review in ~1 day
  : result[Rating.Again].card.due                 // review tomorrow

// Save nextReview to Progress table
await prisma.progress.update({
  where: { id: progressId },
  data: { nextReview: scheduledDate }
})
```

---

### Feature Set: Gemini-Powered "Explain It To Me" (Free — 1,000 req/day)

```javascript
// Google Gemini 2.5 Flash API — Free tier: 1,000 req/day, no CC
// npm install @google/generative-ai

import { GoogleGenerativeAI } from '@google/generative-ai'

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY)
const model = genAI.getGenerativeModel({ model: 'gemini-2.5-flash' })

async function explainConcept(concept: string, lang: 'hi' | 'en', class_: number) {
  const prompt = lang === 'hi'
    ? `तुम Class ${class_} के छात्र के लिए NCERT शिक्षक हो। "${concept}" को सरल हिंदी में समझाओ। 3 चरणों में। उदाहरण दो।`
    : `You are an NCERT teacher for Class ${class_}. Explain "${concept}" simply in 3 steps with a real-world example. Keep it under 100 words.`

  const result = await model.generateContent(prompt)
  return result.response.text()
}

// Rate limiting: max 10 queries/day per Plus user (store in Redis)
// Cache common NCERT questions (Upstash Redis — free 10K commands/day):
import { Redis } from '@upstash/redis'
const redis = new Redis({ url: process.env.UPSTASH_URL, token: process.env.UPSTASH_TOKEN })

const cacheKey = `explain:${concept}:${lang}:${class_}`
const cached = await redis.get(cacheKey)
if (cached) return cached

const response = await explainConcept(concept, lang, class_)
await redis.setex(cacheKey, 86400 * 7, response) // cache 7 days
```

---

### Feature Set: Sarvam AI Voice Layer (Free credits + startup program)

```javascript
// Register at sarvam.ai → Get API key → Activate startup program
// Covers Hindi TTS + STT for 6–12 months free

// Text-to-Speech (read concept to student in Hindi)
async function textToSpeech(text: string) {
  const response = await fetch('https://api.sarvam.ai/text-to-speech', {
    method: 'POST',
    headers: {
      'API-Subscription-Key': process.env.SARVAM_API_KEY,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      inputs: [text],
      target_language_code: 'hi-IN',
      speaker: 'meera', // female Hindi voice
      model: 'bulbul:v1'
    })
  })
  const data = await response.json()
  return data.audios[0] // base64 audio
}

// Speech-to-Text (student asks question via voice)
async function speechToText(audioBase64: string) {
  const response = await fetch('https://api.sarvam.ai/speech-to-text', {
    method: 'POST',
    headers: { 'API-Subscription-Key': process.env.SARVAM_API_KEY },
    body: JSON.stringify({
      model: 'saarika:v2',
      language_code: 'hi-IN',
      audio: audioBase64
    })
  })
  return (await response.json()).transcript
}
```

---

### Feature Set: Bhashini API for Content Translation (Free for Dev/PoC)

```javascript
// Register at bhashini.gov.in → Get userId + API key
// Translate entire NCERT chapter titles, quiz questions, summaries to Hindi

const BHASHINI_API = 'https://dhruva-api.bhashini.gov.in/services/inference/pipeline'

async function translateToHindi(text: string) {
  const response = await fetch(BHASHINI_API, {
    method: 'POST',
    headers: {
      'Authorization': process.env.BHASHINI_API_KEY,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      pipelineTasks: [{
        taskType: 'translation',
        config: {
          language: { sourceLanguage: 'en', targetLanguage: 'hi' },
          serviceId: 'ai4bharat/indictrans-v2-all-gpu--t4'
        }
      }],
      inputData: { input: [{ source: text }] }
    })
  })
  const data = await response.json()
  return data.pipelineResponse[0].output[0].target
}
```

---

### Feature Set: Teacher "Share Class Code" (MVP — No Full Dashboard)

```typescript
// Teacher creates class → gets a 6-character code (e.g., "EDB6MA")
// Students join by entering code in settings
// Teacher sees aggregate class progress (no individual drill-down at MVP)

// Schema addition:
model Class {
  id        String @id @default(cuid())
  code      String @unique @default(cuid()) // 6-char code
  teacherId String
  subject   String
  classNum  Int    // 6, 7, or 8
  students  User[]
  createdAt DateTime @default(now())
}
```

---

## PHASE 3: Scale & Differentiate (Month 9–18)

**Goal:** 2 lakh MAU, ₹50L ARR, 3 state partnerships, Series A ready
**New budget:** ₹1–3L/month (full infra, content production team)

---

### Feature Set: Camera AI Doubt Solver (Pix2Text — Free, Self-Hosted)

```python
# Deploy Pix2Text as a microservice on Render (free tier or $7/month)
# pix2text handles handwritten + printed math → LaTeX → explanation

# requirements.txt:
# pix2text==1.0.2
# fastapi
# uvicorn

# main.py:
from fastapi import FastAPI, UploadFile
from pix2text import Pix2Text

app = FastAPI()
p2t = Pix2Text()

@app.post("/ocr")
async def ocr_image(file: UploadFile):
    contents = await file.read()
    result = p2t.recognize(contents)
    return {"latex": result['text'], "type": result['type']}

# Next.js: send camera image → get LaTeX → send to Gemini for explanation
async function solveDoubt(imageBase64: string, lang: string) {
  // Step 1: OCR via Pix2Text microservice
  const ocrResult = await fetch('https://pix2text.render.app/ocr', {
    method: 'POST',
    body: formData // image file
  })
  const { latex } = await ocrResult.json()

  // Step 2: Explanation via Gemini (free tier)
  const explanation = await explainConcept(latex, lang, userClass)
  return explanation
}
```

---

### Feature Set: Upstash Redis (Free — 10,000 commands/day)

```javascript
// Use for: session cache, leaderboard, rate limiting, API response cache
// Free: 10,000 commands/day (upgrade to $10/month for 100K commands)
// Register at upstash.com → Create Redis database (no CC for free tier)

import { Redis } from '@upstash/redis'
const redis = new Redis({
  url: process.env.UPSTASH_REDIS_URL,
  token: process.env.UPSTASH_REDIS_TOKEN
})

// Weekly leaderboard (auto-reset every Sunday):
await redis.zadd('leaderboard:week:2026-W20', { score: xpEarned, member: userId })
const top10 = await redis.zrange('leaderboard:week:2026-W20', 0, 9, { rev: true, withScores: true })
```

---

## Part 3: Environment Variables Reference

Create `.env.local` with these keys:

```env
# Database (Neon PostgreSQL — Free)
DATABASE_URL=postgresql://user:pass@ep-xxx.us-east-2.aws.neon.tech/edubharat

# Firebase (Auth + FCM — Free)
NEXT_PUBLIC_FIREBASE_API_KEY=
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=
NEXT_PUBLIC_FIREBASE_PROJECT_ID=
NEXT_PUBLIC_FIREBASE_VAPID_KEY=
FIREBASE_ADMIN_SDK_JSON=        # Service account JSON (server-side)

# SMS OTP (Fast2SMS — Near-free ₹100 prepaid)
FAST2SMS_API_KEY=

# Video (Mux — Free: 10 videos + 100K delivery min)
MUX_TOKEN_ID=
MUX_TOKEN_SECRET=

# AI: Google Gemini (Free — 1,000 req/day)
GEMINI_API_KEY=

# AI: Groq (Free — 14,400 req/day)
GROQ_API_KEY=

# India Vernacular AI (Free signup credits)
SARVAM_API_KEY=
BHASHINI_USER_ID=
BHASHINI_API_KEY=
BHASHINI_PIPELINE_ID=

# Storage (Cloudflare R2 — 10 GB free, zero egress)
R2_ACCOUNT_ID=
R2_ACCESS_KEY_ID=
R2_SECRET_ACCESS_KEY=
R2_BUCKET_NAME=edubharat-assets
R2_PUBLIC_URL=https://assets.edubharat.com

# Redis (Upstash — 10,000 commands/day free)
UPSTASH_REDIS_URL=
UPSTASH_REDIS_TOKEN=

# Email (Resend — 3,000/month free)
RESEND_API_KEY=

# WhatsApp (Meta/Interakt)
WHATSAPP_PHONE_NUMBER_ID=
WHATSAPP_ACCESS_TOKEN=

# Analytics (PostHog — 1M events/month free)
NEXT_PUBLIC_POSTHOG_KEY=
NEXT_PUBLIC_POSTHOG_HOST=https://app.posthog.com

# Error Tracking (Sentry — 5,000 errors/month free)
SENTRY_DSN=
NEXT_PUBLIC_SENTRY_DSN=

# JWT
JWT_SECRET=your-32-char-random-secret
```

---

## Part 4: Cost Projection (Monthly Spend)

### Phase 1 (0–10,000 users) — MVP

| Service | Cost | Notes |
|---|---|---|
| Cloudflare Pages (hosting) | ₹0 | Free, unlimited bandwidth |
| Neon PostgreSQL | ₹0 | Free 0.5 GB |
| Firebase Auth + FCM | ₹0 | Free forever |
| Mux Video | ₹0 | Free 10 videos + 100K delivery min |
| Gemini 2.5 Flash | ₹0 | Free 1,000 req/day |
| PostHog | ₹0 | Free 1M events/month |
| Sentry | ₹0 | Free 5K errors/month |
| Upstash Redis | ₹0 | Free 10K commands/day |
| Resend Email | ₹0 | Free 3,000/month |
| Fast2SMS OTP | ~₹500/month | ~3,000 OTPs/month |
| Domain (edubharat.com) | ~₹800/year | One-time |
| **TOTAL PHASE 1** | **~₹500–800/month** | |

### Phase 2 (10,000–50,000 users)

| Service | Cost | Notes |
|---|---|---|
| Cloudflare Pages | ₹0 | Still free |
| Neon PostgreSQL (paid) | ~₹700/month | Upgrade to 10 GB plan |
| Bunny Stream (video CDN) | ~₹1,500/month | ~150 GB bandwidth |
| Sarvam AI | ~₹2,000/month | After free credits |
| WhatsApp BSP (Interakt) | ~₹3,000/month | Starter plan |
| Render API server | ₹0–₹1,500 | Free or $7 upgrade |
| Sentry Team plan | ~₹2,200/month | 5K → 50K errors |
| MSG91 OTP | ~₹2,500/month | ~15K OTPs |
| **TOTAL PHASE 2** | **~₹12,000–15,000/month** | |

### Phase 3 (50,000–2 lakh users)

| Service | Cost | Notes |
|---|---|---|
| Cloudflare Pages | ₹0 | |
| Neon/Supabase (Pro) | ~₹3,500/month | Production PostgreSQL |
| Bunny Stream | ~₹5,000/month | |
| Vercel Pro (or Cloudflare) | ~₹1,700/month | If moving from Pages |
| Sarvam AI | ~₹8,000/month | Scale usage |
| WhatsApp BSP | ~₹7,000/month | Growth plan |
| Claude API (Anthropic) | ~₹8,000/month | Bounded tutor (paid tier) |
| Pix2Text server (Render) | ~₹600/month | $7 plan |
| **TOTAL PHASE 3** | **~₹40,000–50,000/month** | |

---

## Part 5: Folder Structure

```
edubharat/
├── app/
│   ├── (auth)/
│   │   ├── login/page.tsx
│   │   ├── signup/page.tsx
│   │   └── onboarding/page.tsx    ← Placement quiz flow
│   ├── (dashboard)/
│   │   ├── page.tsx               ← Student home (streak, goals)
│   │   ├── subjects/[subject]/page.tsx
│   │   ├── learn/[contentId]/page.tsx  ← Chapter learning flow
│   │   ├── progress/page.tsx
│   │   └── leaderboard/page.tsx
│   ├── (parent)/
│   │   └── dashboard/page.tsx
│   ├── api/
│   │   ├── auth/
│   │   │   ├── send-otp/route.ts  ← Fast2SMS
│   │   │   └── verify-otp/route.ts
│   │   ├── content/
│   │   │   ├── [id]/route.ts
│   │   │   └── progress/route.ts
│   │   ├── ai/
│   │   │   ├── explain/route.ts   ← Gemini API
│   │   │   ├── translate/route.ts ← Bhashini API
│   │   │   └── voice/route.ts     ← Sarvam AI
│   │   ├── notifications/
│   │   │   └── register/route.ts  ← FCM token save
│   │   └── cron/
│   │       ├── streak-reminder/route.ts
│   │       └── weekly-report/route.ts
│   └── layout.tsx
├── components/
│   ├── video/MuxPlayer.tsx
│   ├── quiz/QuizCard.tsx
│   ├── gamification/StreakCounter.tsx
│   ├── gamification/XPBar.tsx
│   ├── curriculum/ChapterMap.tsx  ← Visual node map
│   └── ui/                        ← shadcn/ui components
├── lib/
│   ├── db.ts                      ← Prisma client
│   ├── firebase.ts                ← Firebase config
│   ├── redis.ts                   ← Upstash Redis client
│   ├── streak.ts                  ← Streak logic
│   ├── spaced-repetition.ts       ← FSRS algorithm
│   ├── gemini.ts                  ← Gemini AI client
│   ├── sarvam.ts                  ← Sarvam AI client
│   └── bhashini.ts                ← Bhashini translation
├── prisma/
│   └── schema.prisma
├── public/
│   ├── sw.js                      ← Service worker (auto-generated)
│   └── manifest.json              ← PWA manifest
└── next.config.js                 ← next-pwa config
```

---

## Part 6: Launch Checklist (Before First User)

### Technical
- [ ] Neon database provisioned + Prisma schema pushed
- [ ] Firebase Auth configured (Google + Phone)
- [ ] Fast2SMS DLT template approved (takes 2–3 days in India)
- [ ] Mux account created + first 3 Class 6 Maths videos uploaded
- [ ] FCM push notification configured + test notification sent
- [ ] PWA offline caching tested on Chrome (Network → Offline mode)
- [ ] PostHog tracking verified (events appearing in dashboard)
- [ ] Sentry configured + test error captured
- [ ] Cloudflare Pages deployment live on custom domain
- [ ] Gemini API key active + rate limit tested
- [ ] Bhashini API key active + test translation working
- [ ] Sarvam AI API key active + test TTS working

### Content
- [ ] 30 minimum videos uploaded (Class 6 Maths — all chapters)
- [ ] 150 minimum quiz questions (10 per chapter × 15 chapters)
- [ ] 15 chapter summary PDFs (bilingual) uploaded to Cloudflare R2
- [ ] Placement quiz questions written (10 per subject, spanning grades 4–7)

### Legal & Compliance
- [ ] Privacy Policy page (required for Play Store + App Store later)
- [ ] Terms of Service page
- [ ] COPPA/DPDP Act 2023 compliance (minors' data — parental consent flow)
- [ ] DLT SMS template registered with telecom operator
- [ ] WhatsApp Business API template approved by Meta (3–5 business days)

---

*Last updated: May 2026 | For questions, refer to HANDOFF.md*
