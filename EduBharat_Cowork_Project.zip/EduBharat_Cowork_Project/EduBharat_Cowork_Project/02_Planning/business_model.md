# EduBharat — Business Model & Monetisation
*Status: [DRAFT — NEEDS REVIEW] | Last updated: May 2026*

---

## Revenue Model: Freemium B2C + B2B2C

### Tier 1 — Free (Forever)
Target: Build user base, establish trust, generate word-of-mouth

**What's Free:**
- 3 video capsules per day (per subject)
- 5 practice questions per chapter
- Basic streak + XP gamification
- Class-level leaderboard
- 1 subject bookmark
- Hindi + English toggle
- Basic progress tracker
- NCERT Solutions (text-based, no video)

**Free Limits:**
- No offline download
- No AI Doubt Solver
- No national leaderboard
- No badge collection (only 5 basic badges)
- No quiz battle mode

---

### Tier 2 — EduBharat Plus (₹299/month or ₹2,499/year)
Target: Serious students, parents who see ROI in grades improving

**What's Included:**
- Unlimited video capsules (all subjects, all classes)
- Unlimited adaptive practice sets
- AI Doubt Solver (photo + text, unlimited)
- National leaderboard + full badge system (50+ badges)
- Offline download (10 videos + 5 practice sets per subject)
- Adaptive test generator (personalised weak-topic tests)
- CBSE sample papers (all years, auto-graded)
- Priority doubt answer (within 2 hours vs 24 hours)
- Progress reports (student + parent) with insights
- Coding module full access (Scratch, Python)
- Quiz Battle Mode (unlimited battles)
- WhatsApp weekly progress card for parents

**Pricing Rationale:**
- ₹299/month = less than one tuition class
- ₹2,499/year = ₹208/month effective (2 months free)
- Compare: Byju's = ₹1,500-3,500/month; Vedantu = ₹400-1,000/month

---

### Tier 3 — School/Institutional Plan
Target: Schools, coaching centres, NGOs (B2B2C)

**Pricing:**
- ₹499/student/year (minimum 50 students)
- ₹399/student/year (100+ students)
- ₹299/student/year (500+ students — district/state level)

**What Schools Get:**
- All Plus features for every student
- Teacher dashboard (full analytics, homework assignment, test creation)
- Principal/admin portal (school-wide analytics, usage reports)
- Custom school branding option
- Teacher onboarding session (online, 1 hour)
- API integration with school ERP systems (Phase 3)
- Offline support for schools with poor connectivity
- Monthly school performance report (WhatsApp/email to principal)

---

## Revenue Projections (Year 1)

| Stream | Month 3 | Month 6 | Month 12 |
|--------|---------|---------|---------|
| Free Users | 5,000 | 20,000 | 80,000 |
| Plus Subscribers | 100 | 500 | 2,000 |
| School Seats | 200 | 1,000 | 5,000 |
| Plus MRR | ₹29,900 | ₹1,49,500 | ₹5,98,000 |
| School ARR | ₹99,800 | ₹4,99,000 | ₹24,95,000 |
| **Total ARR (Year 1)** | — | — | **₹96L+ (~₹1Cr)** |

---

## Additional Revenue Opportunities (Phase 2-3)

| Revenue Stream | Description | Potential |
|---------------|-------------|---------|
| Olympiad prep packs | IMO/NSO/IEO specific course add-ons (₹499 each) | Medium |
| Live doubt classes | Weekly live session with expert teacher (₹199/session) | High |
| Parent workshops | Online webinars for parents on supporting learning (₹299/session) | Low-Medium |
| Content licensing | License NCERT-aligned content to other edtech/schools | High (Phase 3) |
| Teacher certification | Certified EduBharat teacher program (₹1,999) | Medium |
| NGO/CSR grants | Apply for Govt + CSR digital education funding | High (Phase 2) |

---

## Cost Structure Estimate

| Item | Monthly Cost (MVP) | Notes |
|------|-------------------|-------|
| Video production (animated) | ₹2-4L | 10-15 videos/month outsourced |
| Tech (servers, CDN) | ₹30-50K | AWS/GCP India region |
| Tech team (2 devs) | ₹1.5-2.5L | Noida/Delhi market rate |
| Content team (2 educators) | ₹80K-1.2L | NCERT subject experts |
| Design (1 UI/UX) | ₹60-80K | |
| Marketing | ₹50K-1L | Social + school outreach |
| **Total Monthly Burn** | **₹5-9L** | Reduce with content partnerships |

---

## Funding Strategy [NEEDS REVIEW]

### Bootstrap Phase (Months 1-4)
- Self-fund MVP build: ₹15-20L estimated
- Focus: Build product, get first 10 schools onboarded

### Seed Round (Month 5-8)
- Target: ₹1-2Cr seed raise
- From: Angel investors in Indian EdTech (EduTech angels, family offices)
- Use: Content production scale-up, marketing, team expansion

### Series A (Month 12-18)
- Target: ₹5-15Cr
- Trigger: 50,000+ MAU, ₹1Cr+ ARR, clear retention metrics
- From: Indian EdTech VCs (Fireside Ventures, Blume, Lightspeed India)

---

## Strategic Partnerships to Pursue

| Partner Type | Target | Benefit |
|-------------|--------|---------|
| Government | DIKSHA, PM e-VIDYA | Content credibility + free distribution |
| NGOs | Pratham, Teach For India | Access to govt school students |
| Telecom | Jio, BSNL | Zero-rated data (free access on Jio network) |
| Publishers | NCERT, Oswaal | Co-branded content + distribution |
| School chains | Delhi Public School, Kendriya Vidyalaya | 100s of schools in one deal |
| Teacher networks | CBSE teacher WhatsApp groups | Grassroots teacher adoption |
