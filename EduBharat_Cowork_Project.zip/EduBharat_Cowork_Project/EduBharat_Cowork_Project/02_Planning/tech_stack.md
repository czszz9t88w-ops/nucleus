# EduBharat — Technology Stack
*Status: [DRAFT — NEEDS REVIEW] | Last updated: May 2026*

---

## Architecture Overview

```
┌─────────────────────────────────────────────┐
│              STUDENT / TEACHER              │
│         Web Browser  |  Android App         │
└──────────────────┬──────────────────────────┘
                   │
┌──────────────────▼──────────────────────────┐
│           FRONTEND (PWA + React)            │
│  - Next.js (SEO + SSR for web)              │
│  - React Native (Android app Phase 3)       │
│  - Service Worker (offline support)         │
└──────────────────┬──────────────────────────┘
                   │
┌──────────────────▼──────────────────────────┐
│              BACKEND API                    │
│  - Node.js + Express / FastAPI (Python)     │
│  - REST API + WebSockets (live features)    │
└──────┬──────────────────────┬───────────────┘
       │                      │
┌──────▼──────┐    ┌──────────▼──────────────┐
│  DATABASE   │    │    AI / ML SERVICES      │
│  PostgreSQL │    │  - OpenAI / Claude API   │
│  Redis      │    │  - Doubt solver model    │
│  (caching)  │    │  - Adaptive engine       │
└─────────────┘    └─────────────────────────┘
       │
┌──────▼──────────────────────────────────────┐
│           CLOUD INFRASTRUCTURE              │
│  AWS India (ap-south-1 Mumbai)              │
│  - EC2 / ECS (app servers)                  │
│  - S3 (video storage)                       │
│  - CloudFront CDN (video delivery)          │
│  - RDS (PostgreSQL managed)                 │
│  - ElastiCache (Redis)                      │
└─────────────────────────────────────────────┘
```

---

## Frontend Stack

| Layer | Technology | Reason |
|-------|-----------|--------|
| Framework | Next.js 14 (React) | SSR for SEO; fast load; PWA support |
| Styling | Tailwind CSS | Rapid UI development; mobile-first |
| Animation | Framer Motion | Smooth gamification animations |
| State Management | Zustand | Lightweight; easy for team |
| Video Player | Video.js | Open-source; adaptive bitrate; offline |
| Coding Module | Scratch SDK + Pyodide | Scratch visual; Python in-browser |
| Offline | Workbox (Service Worker) | Google's offline toolkit |
| Charts/Progress | Recharts | React-native compatible |

---

## Backend Stack

| Layer | Technology | Reason |
|-------|-----------|--------|
| Runtime | Node.js 20 LTS | Team familiarity; large ecosystem |
| Framework | Express.js | Lightweight; flexible |
| Auth | Firebase Auth OR JWT | Easy social login (Google, phone OTP) |
| Database | PostgreSQL (primary) | Relational; handles complex queries |
| Cache | Redis | Session data; leaderboard real-time |
| Queue | Bull (Redis-based) | Background jobs (report generation) |
| File Storage | AWS S3 | Videos, images, PDFs |
| Video Streaming | AWS CloudFront + S3 | Low-latency delivery across India |
| Search | Elasticsearch (Phase 2) | Content search; question bank |

---

## AI / ML Services

| Feature | Technology | Notes |
|---------|-----------|-------|
| Photo Doubt Solver | Claude API (Anthropic) + OCR | Student photos textbook question → AI solves |
| Text Doubt Chatbot | Claude API | Subject-specific system prompts |
| Adaptive Question Engine | Custom ML model (scikit-learn) | Tracks question performance → adjusts difficulty |
| Content Recommendation | Collaborative filtering | "Students like you also learned..." |
| Weak Topic Detection | Rule-based + ML | Analyzes error patterns per chapter |

---

## Mobile Strategy

### Phase 1: PWA (Progressive Web App)
- Works on Chrome/Firefox on Android without Play Store
- Installable via "Add to Home Screen"
- Offline support via Service Worker
- Push notifications for streaks, new content
- **Advantage:** Ship faster, lower cost, no app store approval

### Phase 3: Native Android App
- React Native (reuse 80% of web codebase)
- Play Store listing
- Deeper offline capabilities
- Better camera integration (photo doubt upload)
- **Minimum Android version:** 8.0 (covers 92% of Indian market)

---

## Infrastructure & DevOps

| Item | Technology | Notes |
|------|-----------|-------|
| Cloud | AWS Mumbai (ap-south-1) | Lowest latency for India |
| CDN | AWS CloudFront | Video delivery <100ms latency |
| Containerization | Docker + ECS | Scalable; easy deployment |
| CI/CD | GitHub Actions | Auto-deploy on merge |
| Monitoring | Datadog OR Sentry | Error tracking + performance |
| Video Encoding | AWS Elastic Transcoder | HLS adaptive bitrate (low-data mode) |
| Email | AWS SES | Cheap; reliable for India |
| WhatsApp | WhatsApp Business API | Parent weekly reports |
| Analytics | Mixpanel + Amplitude | User behavior tracking |

---

## Estimated Monthly Tech Costs (MVP)

| Service | Monthly Cost |
|---------|-------------|
| AWS (servers + storage + CDN) | ₹25,000-45,000 |
| Claude/OpenAI API (AI features) | ₹10,000-20,000 |
| Monitoring + tools | ₹5,000-10,000 |
| Domain + SSL | ₹1,000 |
| WhatsApp Business API | ₹5,000-8,000 |
| **Total** | **₹46,000-84,000/month** |

---

## Security & Compliance

- **HTTPS everywhere** — no HTTP connections
- **DPDP Act 2023 compliance** — parental consent for under-18 data
- **No selling student data** — written into privacy policy + contracts
- **Password hashing** — bcrypt (never store plain passwords)
- **Rate limiting** — prevent API abuse
- **Content moderation** — AI + human review for user-generated content (doubt forum)
- **COPPA-equivalent** — parental approval workflow for account creation under 13

---

## Domain & Branding [NEEDS REVIEW — Rishav to decide]

Suggested domain options:
1. `edubharat.in` — Clear India identity
2. `padho.in` — Hindi (Let's Study)
3. `seekho.co.in` — Hindi (Let's Learn)
4. `bharatlearn.com` — English

Recommend: Lock domain immediately before launch announcement.
