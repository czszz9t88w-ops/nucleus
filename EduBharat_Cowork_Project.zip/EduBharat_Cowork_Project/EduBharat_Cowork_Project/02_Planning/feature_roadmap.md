# EduBharat — Feature Roadmap
*Status: [FINAL] | Last updated: May 2026*

---

## Phase 1 — MVP (Months 1-4)
**Goal:** Launch with Class 6 only. 2 subjects (Maths + Science). Prove engagement metrics.

### Must-Have Features (Phase 1)
- [ ] User registration (Student / Parent / Teacher roles)
- [ ] Class 6 Maths — All chapters, video capsules + practice sets
- [ ] Class 6 Science — All chapters, video capsules + practice sets
- [ ] Daily Streak + XP Points system
- [ ] Chapter progress map (visual level map)
- [ ] Basic leaderboard (class-level)
- [ ] 3 badge types (Completion, Speed, Accuracy)
- [ ] Hindi + English language toggle
- [ ] Basic parent dashboard (progress report)
- [ ] Teacher dashboard — assign homework, view class progress
- [ ] PWA (Progressive Web App) — installable on Android
- [ ] Offline content download (3 videos + 2 practice sets)
- [ ] NCERT Solutions (Class 6 Maths + Science)
- [ ] Basic AI doubt solver (text-based)
- [ ] Photo doubt upload (question → AI answer)
- [ ] NEP 2020: Coding Module (Scratch, Class 6)

### Phase 1 Success Metrics
- 1,000 student registrations within 30 days of launch
- Average session duration: 15+ minutes
- Day 7 retention: 40%+
- Net Promoter Score (NPS): 50+
- 5+ schools formally adopted (teacher dashboard activated)

---

## Phase 2 — Growth (Months 5-8)
**Goal:** Expand to full Class 6-8, all subjects, premium tier launch.

### Features to Add (Phase 2)
- [ ] Class 7 + Class 8 — All subjects and chapters
- [ ] Social Studies (History, Geography, Civics) — Class 6, 7, 8
- [ ] Hindi + English Literature modules
- [ ] Premium tier launch (₹299/month — unlimited access)
- [ ] National leaderboard (city + country rankings)
- [ ] Full badge system (50+ achievement badges)
- [ ] Quiz Battle Mode (1v1 timed quiz vs friend or AI)
- [ ] Streak Shield feature
- [ ] Adaptive Test Generator (AI-based, weak-topic-focused)
- [ ] CBSE Sample Papers (Class 6, 7, 8) — auto-graded
- [ ] Virtual Lab Simulations (Science — Physics, Chemistry, Biology)
- [ ] Python blocks coding (Class 7)
- [ ] WhatsApp parent report card integration
- [ ] Olympiad prep module (IMO, NSO, IEO basics)
- [ ] Bonus Events (Republic Day Quiz, Diwali Challenge, etc.)
- [ ] School-level analytics portal for principals

### Phase 2 Success Metrics
- 10,000 active students (monthly)
- 500 paid subscribers (₹299/month)
- 50+ schools onboarded
- Day 30 retention: 30%+

---

## Phase 3 — Scale (Months 9-12)
**Goal:** State board expansion, regional languages, institutional revenue.

### Features to Add (Phase 3)
- [ ] UP Board, MP Board, Maharashtra Board content mapping
- [ ] Marathi + Tamil + Telugu content (videos + UI)
- [ ] Python text-based coding (Class 8 full course)
- [ ] Life Skills module (Health, Financial literacy, Citizenship)
- [ ] Career Discovery module (personality quiz → career paths)
- [ ] Creative Arts module (NEP 2020 compliance)
- [ ] School institutional licensing (bulk seats model)
- [ ] API for school ERP integration
- [ ] Teacher community forum (educator network)
- [ ] Content creator program (verified teachers submit content)
- [ ] Referral system (student refers → earns bonus XP)
- [ ] Android native app (Play Store listing)

### Phase 3 Success Metrics
- 50,000 monthly active users
- ₹10L+ monthly recurring revenue (MRR)
- 200+ schools on institutional plan
- 3+ state board content sets live

---

## Feature Priority Matrix

| Feature | Student Value | Teacher Value | Business Value | Priority |
|---------|-------------|--------------|----------------|---------|
| Video Capsules (NCERT) | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | P0 |
| Practice Sets (adaptive) | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | P0 |
| Daily Streak/XP | ⭐⭐⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐⭐⭐ | P0 |
| Teacher Dashboard | ⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | P0 |
| Hindi/English Toggle | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | P0 |
| Offline Mode | ⭐⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐ | P0 |
| AI Doubt Solver | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | P1 |
| Quiz Battle Mode | ⭐⭐⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐ | P1 |
| Virtual Labs | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | P2 |
| Coding Module | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ | P1 |
| State Board Content | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | P2 |
| Career Discovery | ⭐⭐⭐ | ⭐⭐ | ⭐⭐ | P3 |
